package it.smellsliketeamspirit.themealdbfragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;


import android.content.res.Configuration;
import android.os.Bundle;


import it.smellsliketeamspirit.themealdbfragments.fragments.FragmentDetail;
import it.smellsliketeamspirit.themealdbfragments.fragments.FragmentList;

public class MainActivity extends AppCompatActivity {


  public static FragmentManager fragmentManager;
  FragmentList fragmentList;
  FragmentDetail fragmentDetail;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    fragmentManager = getSupportFragmentManager();

    int orientation = this.getResources().getConfiguration().orientation;
    if (orientation == Configuration.ORIENTATION_PORTRAIT) {
      portrait();
    } else {
      landscape();
    }
  }

  private void portrait() {
    fragmentDetail = new FragmentDetail();
    fragmentList = new FragmentList(this::switchFragment);
    removeFragments();
    getSupportFragmentManager()
        .beginTransaction()
        .replace(R.id.listFrame, fragmentList)
        .commit();
  }

  private void landscape() {
    fragmentDetail = new FragmentDetail();
    fragmentList = new FragmentList();

    removeFragments();
    getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.detailFrame, fragmentDetail)
            .commit();
    getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.listFrame, fragmentList)
            .commit();
  }

  void switchFragment() {

    // Code with Framework Animation instead of Framework Transition
//      getSupportFragmentManager()
//          .beginTransaction()
//          .setCustomAnimations(
//                  R.anim.slide_in, // enter
//                  R.anim.fade_out  // exit
//          )
//          .replace(R.id.listFrame,
//              fragmentDetail)
//          .addToBackStack("MASTER")
//          .commit();

      getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.listFrame,
                    fragmentDetail)
            .addToBackStack("MASTER")
            .commit();
  }

  private void removeFragments() {
    getSupportFragmentManager()
            .beginTransaction()
            .remove(fragmentList)
            .commit();
    getSupportFragmentManager()
            .beginTransaction()
            .remove(fragmentDetail)
            .commit();
  }

}
