package it.smellsliketeamspirit.themealdbfragments.fragments;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Html;
import android.transition.TransitionInflater;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import it.smellsliketeamspirit.themealdbfragments.R;
import it.smellsliketeamspirit.themealdbfragments.entities.Meal;
import it.smellsliketeamspirit.themealdbfragments.viewmodel.MealViewModel;

public class FragmentDetail extends Fragment {

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_detail, container, false);
    TransitionInflater transInflater = TransitionInflater.from(requireContext());
    setExitTransition(transInflater.inflateTransition(R.transition.slide_right));
    return view;
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    MealViewModel model = new ViewModelProvider(requireActivity())
        .get(MealViewModel.class);
    model
        .getInfo()
        .observe(getViewLifecycleOwner(), item -> new Holder(view, item));
  }

  class Holder {
    final TextView tv;
    final TextView tvIngredients;
    final TextView tvInstructions;
    final ImageView ivMeal;

    Holder(View view, Meal meal) {
      view.findViewById(R.id.svBase).setVisibility(View.VISIBLE);
      tv = view.findViewById(R.id.tvMealName);
      tvIngredients = view.findViewById(R.id.tvIngredients);
      tvInstructions = view.findViewById(R.id.tvPreparation);
      ivMeal = view.findViewById(R.id.ivMealRead);

      fillLayout(meal);
    }

    void fillLayout(Meal meal) {
      tv.setText(meal.strMeal);
      tvInstructions.setText(meal.strInstructions);
      tvIngredients.setText(Html.fromHtml(meal.getIngredients(getContext()),
          Html.FROM_HTML_MODE_COMPACT));


      ImageRequest request = new ImageRequest(meal.strMealThumb,
          ivMeal::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888,
          error -> ivMeal.setImageResource(R.drawable.logo));
      if(getActivity() != null) {
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
      }
    }
  }
}
