package it.smellsliketeamspirit.themealdbfragments.fragments;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.transition.TransitionInflater;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import it.smellsliketeamspirit.themealdbfragments.R;
import it.smellsliketeamspirit.themealdbfragments.adapters.MealAdapter;
import it.smellsliketeamspirit.themealdbfragments.entities.Meal;
import it.smellsliketeamspirit.themealdbfragments.interfaces.NextFragment;
import it.smellsliketeamspirit.themealdbfragments.interfaces.SelectMode;
import it.smellsliketeamspirit.themealdbfragments.requests.MealAPI;
import it.smellsliketeamspirit.themealdbfragments.viewmodel.MealViewModel;
import it.smellsliketeamspirit.themealdbfragments.viewmodel.MealListViewModel;

public class FragmentList extends Fragment implements SelectMode {
  private MealAdapter mealAdapter;
  private RecyclerView rv;
  private MealAPI api;
  private NextFragment nf;
  private MealListViewModel clm;
  @SuppressWarnings("FieldCanBeLocal")
  private MealViewModel svm;

  public FragmentList() {

  }

  public FragmentList(NextFragment nf) {
    this.nf = nf;
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
     View view = inflater.inflate(R.layout.fragment_list, container, false);
     TransitionInflater transInflater = TransitionInflater.from(requireContext());
     setExitTransition(transInflater.inflateTransition(R.transition.fade));
     return view;
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    Holder holder = new Holder(view);
    clm = new ViewModelProvider(requireActivity()).get(MealListViewModel.class);
    clm.getMeals().observe(getViewLifecycleOwner(), holder::setList);
  }

  private void onClickAPICallBack(Meal meal) {
    svm = new ViewModelProvider(requireActivity()).get(MealViewModel.class);
    svm.loadInfo(meal);
    if(nf != null) {
      nf.nextFragment();
    }
  }

  @Override
  public void onStop() {
    if(mealAdapter != null)
      clm.setMeals(mealAdapter.getMeals());
    super.onStop();
  }

  @Override
  public void onSelect(int size) {

  }


  class Holder implements View.OnClickListener, TextView.OnEditorActionListener {
    EditText etSearch;
    Button btnSearch;

    Holder(View fl) {
      etSearch = fl.findViewById(R.id.etSearch);
      btnSearch = fl.findViewById(R.id.btnSearch);
      etSearch.setOnEditorActionListener(this);
      btnSearch.setOnClickListener(this);
      RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
      rv = fl.findViewById(R.id.rvMealList);
      rv.setLayoutManager(layoutManager);
      if(getActivity() != null) {
        api = new MealAPI(getActivity(), "1") {
          @Override
          public void fillLayout(List<Meal> meals) {
            mealAdapter = new MealAdapter(getActivity(), meals, FragmentList.this) {
              @Override
              public void onClickAdapterCallBack(Meal meal) {
                onClickAPICallBack(meal);
              }
            };
            rv.setAdapter(mealAdapter);
            clm.setMeals(mealAdapter.getMeals());
          }
        };
      }
      if(getContext() != null) {
        Drawable drw = ContextCompat.getDrawable(getContext(), R.drawable.my_divider);
        if (drw != null) {
          DividerItemDecoration itemDecorator = new DividerItemDecoration(getContext(),
                  DividerItemDecoration.VERTICAL);
          itemDecorator.setDrawable(drw);
          rv.addItemDecoration(itemDecorator);

        }
      }
    }

    private void search() {
      api.search(etSearch.getText().toString());
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
      if (actionId == EditorInfo.IME_ACTION_SEARCH
          || actionId == EditorInfo.IME_ACTION_DONE) {
        search();

        return false;
      }
      return false;
    }

    @Override
    public void onClick(View v) {
        search();
    }

    void setList(List<Meal> meals) {
      if (meals == null)
        return;
      if(getActivity() != null) {
        mealAdapter = new MealAdapter(getActivity(), meals, FragmentList.this) {
          @Override
          public void onClickAdapterCallBack(Meal meal) {
            onClickAPICallBack(meal);
          }
        };
        rv.setAdapter(mealAdapter);
      }
    }
  }
}

