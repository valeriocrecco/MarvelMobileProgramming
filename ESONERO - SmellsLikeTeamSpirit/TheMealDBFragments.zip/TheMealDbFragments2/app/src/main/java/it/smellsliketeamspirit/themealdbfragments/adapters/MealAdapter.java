package it.smellsliketeamspirit.themealdbfragments.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageRequest;

import java.util.List;

import it.smellsliketeamspirit.themealdbfragments.R;
import it.smellsliketeamspirit.themealdbfragments.entities.Meal;
import it.smellsliketeamspirit.themealdbfragments.interfaces.SelectMode;

public abstract class MealAdapter extends RecyclerView.Adapter<MealAdapter.Holder> implements View.OnClickListener, View.OnLongClickListener {
  private final List<Meal> meals;
  private RequestQueue queue;

  public abstract void onClickAdapterCallBack(Meal meal);

  public List<Meal> getMeals() {
    return meals;
  }

  private SelectMode mListener;
  private SparseBooleanArray selectedList = new SparseBooleanArray();

  @SuppressWarnings("unused")
  public void deleteAllSelected() {
    if (selectedList.size()==0) { return; }
    for (int index = meals.size()-1; index >=0; index--) {
      if (selectedList.get(index,false)) {
        remove(index);
      }
    }
    selectedList.clear();
  }

  private void remove(int position) {
    meals.remove(position);
    notifyItemRemoved(position);
  }

  protected MealAdapter(Context context, List<Meal> all, SelectMode listener) {
    meals = all;
    mListener = listener;
// Uso della cache
    Cache cache = new DiskBasedCache(context.getCacheDir(), 16 * 1024 * 1024); // 16MB
    Network network = new BasicNetwork(new HurlStack());
    queue = new RequestQueue(cache, network);
    queue.start();
  }

  @NonNull
  @Override
  public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    CardView cl;
    cl = (CardView) LayoutInflater
        .from(parent.getContext())
        .inflate(R.layout.item_meal, parent, false);
    cl.setOnClickListener(this);
    cl.setOnLongClickListener(this);
    return new Holder(cl);
  }

  @Override
  public void onBindViewHolder(@NonNull Holder holder, int position) {
    Meal meal = meals.get(position);
    holder.tvMeal.setText(meal.strMeal);
    getImage(position, meal.strMealThumb, holder.ivMeal);
    holder.ivMeal.setImageResource(R.drawable.logo);
    boolean isSelected = selectedList.get(position,false);
    if(isSelected) {
      holder.clContainer.setSelected(true);
      holder.tvMeal.setTypeface(null, Typeface.BOLD);
    } else {
      holder.clContainer.setSelected(false);
      holder.tvMeal.setTypeface(null, Typeface.NORMAL);
    }
  }

  private void getImage(int position, String strMealThumb, final ImageView mImageView) {
    queue.cancelAll(position);
    ImageRequest request = new ImageRequest(strMealThumb,
        mImageView::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888,
        error -> mImageView.setImageResource(R.drawable.logo));
    request.setTag(position);
    queue.add(request);
  }

  @Override
  public int getItemCount() {
    return meals.size();
  }

  @Override
  public void onClick(View v) {
    if(selectedList.size() > 0) {
     onLongClick(v);
    } else {
      int position = ((RecyclerView) v.getParent()).getChildAdapterPosition(v);
      Meal meal = meals.get(position);
      onClickAdapterCallBack(meal);
    }
  }

  @Override
  public boolean onLongClick(View v) {
    int position = ((RecyclerView) v.getParent()).getChildAdapterPosition(v);

    boolean isSel = selectedList.get(position, false);
    if(isSel) {
      v.setSelected(false);
      selectedList.delete(position);
    } else {
      v.setSelected(true);
      selectedList.put(position, true);
    }
    if (mListener != null) {
      mListener.onSelect(selectedList.size());  // Callback verso MainActivity
    }
    notifyDataSetChanged();
    return true;
  }

  @SuppressWarnings("unused")
  public void deselectAll() {
    selectedList.clear();

    notifyDataSetChanged();
  }

  @SuppressWarnings("unused")
  public void selectAll() {
    for(int i = 0; i < meals.size(); i++) {
      selectedList.put(i, true);
    }
    notifyDataSetChanged();
  }

  static class Holder extends RecyclerView.ViewHolder {
    final TextView tvMeal;
    final ImageView ivMeal;
    ConstraintLayout  clContainer;

    Holder(@NonNull View itemView) {
      super(itemView);
      tvMeal = itemView.findViewById(R.id.tvMealRead);
      ivMeal = itemView.findViewById(R.id.ivMealRead);
      clContainer = itemView.findViewById(R.id.clItemMealLayout);
    }
  }
}

