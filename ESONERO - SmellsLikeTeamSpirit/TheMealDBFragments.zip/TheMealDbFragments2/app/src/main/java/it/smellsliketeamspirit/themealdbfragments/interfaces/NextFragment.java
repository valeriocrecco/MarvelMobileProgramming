package it.smellsliketeamspirit.themealdbfragments.interfaces;

public interface NextFragment {
  void nextFragment();
}
