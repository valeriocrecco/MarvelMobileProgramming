package it.smellsliketeamspirit.themealdbfragments.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import it.smellsliketeamspirit.themealdbfragments.entities.Meal;

public class MealViewModel extends ViewModel {
  private MutableLiveData<Meal> info;


  public LiveData<Meal> getInfo() {
    if(info == null)
      info = new MutableLiveData<>();
    return info;
  }

  public void loadInfo(Meal meal) {
    if(info == null)
      info = new MutableLiveData<>();
    info.setValue(meal);
  }
}
