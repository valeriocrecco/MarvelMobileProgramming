package it.smellsliketeamspirit.themealdbfragments.entities;

// COSA SONO I PARCELABLE

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.lang.reflect.Field;
import java.util.Locale;

import it.smellsliketeamspirit.themealdbfragments.R;


@Entity(tableName="meals")
public class Meal implements Parcelable {
  @PrimaryKey(autoGenerate = true)
  @ColumnInfo(name="_id")
  public int idMeal;
  @ColumnInfo(name="strMeal")
  public String strMeal;
  @ColumnInfo(name="strDrinkAlternate")
  public String strDrinkAlternate;
  @ColumnInfo(name="strCategory")
  public String strCategory;
  @ColumnInfo(name="strArea")
  public String strArea;
  @ColumnInfo(name="strInstructions")
  public String strInstructions;
  @ColumnInfo(name="strMealThumb")
  public String strMealThumb;
  @ColumnInfo(name="strTags")
  public String strTags;
  @ColumnInfo(name="strYoutube")
  public String strYoutube;
  @ColumnInfo(name="strIngredient1")
  public String strIngredient1;
  @ColumnInfo(name="strIngredient2")
  public String strIngredient2;
  @ColumnInfo(name="strIngredient3")
  public String strIngredient3;
  @ColumnInfo(name="strIngredient4")
  public String strIngredient4;
  @ColumnInfo(name="strIngredient5")
  public String strIngredient5;
  @ColumnInfo(name="strIngredient6")
  public String strIngredient6;
  @ColumnInfo(name="strIngredient7")
  public String strIngredient7;
  @ColumnInfo(name="strIngredient8")
  public String strIngredient8;
  @ColumnInfo(name="strIngredient9")
  public String strIngredient9;
  @ColumnInfo(name="strIngredient10")
  public String strIngredient10;
  @ColumnInfo(name="strIngredient11")
  public String strIngredient11;
  @ColumnInfo(name="strIngredient12")
  public String strIngredient12;
  @ColumnInfo(name="strIngredient13")
  public String strIngredient13;
  @ColumnInfo(name="strIngredient14")
  public String strIngredient14;
  @ColumnInfo(name="strIngredient15")
  public String strIngredient15;
  @ColumnInfo(name="strIngredient16")
  public String strIngredient16;
  @ColumnInfo(name="strIngredient17")
  public String strIngredient17;
  @ColumnInfo(name="strIngredient18")
  public String strIngredient18;
  @ColumnInfo(name="strIngredient19")
  public String strIngredient19;
  @ColumnInfo(name="strIngredient20")
  public String strIngredient20;
  @ColumnInfo(name="strMeasure1")
  public String strMeasure1;
  @ColumnInfo(name="strMeasure2")
  public String strMeasure2;
  @ColumnInfo(name="strMeasure3")
  public String strMeasure3;
  @ColumnInfo(name="strMeasure4")
  public String strMeasure4;
  @ColumnInfo(name="strMeasure5")
  public String strMeasure5;
  @ColumnInfo(name="strMeasure6")
  public String strMeasure6;
  @ColumnInfo(name="strMeasure7")
  public String strMeasure7;
  @ColumnInfo(name="strMeasure8")
  public String strMeasure8;
  @ColumnInfo(name="strMeasure9")
  public String strMeasure9;
  @ColumnInfo(name="strMeasure10")
  public String strMeasure10;
  @ColumnInfo(name="strMeasure11")
  public String strMeasure11;
  @ColumnInfo(name="strMeasure12")
  public String strMeasure12;
  @ColumnInfo(name="strMeasure13")
  public String strMeasure13;
  @ColumnInfo(name="strMeasure14")
  public String strMeasure14;
  @ColumnInfo(name="strMeasure15")
  public String strMeasure15;
  @ColumnInfo(name="strMeasure16")
  public String strMeasure16;
  @ColumnInfo(name="strMeasure17")
  public String strMeasure17;
  @ColumnInfo(name="strMeasure18")
  public String strMeasure18;
  @ColumnInfo(name="strMeasure19")
  public String strMeasure19;
  @ColumnInfo(name="strMeasure20")
  public String strMeasure20;
  @ColumnInfo(name="strSource")
  public String strSource;
  @ColumnInfo(name="dateModified")
  public String dateModified;

  public static final Creator<Meal> CREATOR = new Creator<Meal>() {
    @Override
    public Meal createFromParcel(Parcel in) {
      return new Meal(in);
    }

    @Override
    public Meal[] newArray(int size) {
      return new Meal[size];
    }
  };

  @Override
  public int describeContents() {
    return 0;
  }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
      dest.writeInt(idMeal);
      dest.writeString(strMeal);
      dest.writeString(strDrinkAlternate);
      dest.writeString(strCategory);
      dest.writeString(strArea);
      dest.writeString(strInstructions);
      dest.writeString(strMealThumb);
      dest.writeString(strTags);
      dest.writeString(strYoutube);
      dest.writeString(strIngredient1);
      dest.writeString(strIngredient2);
      dest.writeString(strIngredient3);
      dest.writeString(strIngredient4);
      dest.writeString(strIngredient5);
      dest.writeString(strIngredient6);
      dest.writeString(strIngredient7);
      dest.writeString(strIngredient8);
      dest.writeString(strIngredient9);
      dest.writeString(strIngredient10);
      dest.writeString(strIngredient11);
      dest.writeString(strIngredient12);
      dest.writeString(strIngredient13);
      dest.writeString(strIngredient14);
      dest.writeString(strIngredient15);
      dest.writeString(strIngredient16);
      dest.writeString(strIngredient17);
      dest.writeString(strIngredient18);
      dest.writeString(strIngredient19);
      dest.writeString(strIngredient20);
      dest.writeString(strMeasure1);
      dest.writeString(strMeasure2);
      dest.writeString(strMeasure3);
      dest.writeString(strMeasure4);
      dest.writeString(strMeasure5);
      dest.writeString(strMeasure6);
      dest.writeString(strMeasure7);
      dest.writeString(strMeasure8);
      dest.writeString(strMeasure9);
      dest.writeString(strMeasure10);
      dest.writeString(strMeasure11);
      dest.writeString(strMeasure12);
      dest.writeString(strMeasure13);
      dest.writeString(strMeasure14);
      dest.writeString(strMeasure15);
      dest.writeString(strMeasure16);
      dest.writeString(strMeasure17);
      dest.writeString(strMeasure18);
      dest.writeString(strMeasure19);
      dest.writeString(strMeasure20);
      dest.writeString(strSource);
      dest.writeString(dateModified);
  }

  public String getStrGlass() {
    return strMeal;
  }

  public void setStrGlass(String strMeal) {
    this.strMeal = strMeal;
  }

  public Meal() {

  }

  private Meal(Parcel in) {
    idMeal = in.readInt();
    strMeal = in.readString();
    strDrinkAlternate = in.readString();
    strCategory = in.readString();
    strArea = in.readString();
    strInstructions = in.readString();
    strMealThumb = in.readString();
    strTags = in.readString();
    strYoutube = in.readString();
    strIngredient1 = in.readString();
    strIngredient2 = in.readString();
    strIngredient3 = in.readString();
    strIngredient4 = in.readString();
    strIngredient5 = in.readString();
    strIngredient6 = in.readString();
    strIngredient7 = in.readString();
    strIngredient8 = in.readString();
    strIngredient9 = in.readString();
    strIngredient10 = in.readString();
    strIngredient11 = in.readString();
    strIngredient12 = in.readString();
    strIngredient13 = in.readString();
    strIngredient14 = in.readString();
    strIngredient15 = in.readString();
    strIngredient16 = in.readString();
    strIngredient17 = in.readString();
    strIngredient18 = in.readString();
    strIngredient19 = in.readString();
    strIngredient20 = in.readString();
    strMeasure1 = in.readString();
    strMeasure2 = in.readString();
    strMeasure3 = in.readString();
    strMeasure4 = in.readString();
    strMeasure5 = in.readString();
    strMeasure6 = in.readString();
    strMeasure7 = in.readString();
    strMeasure8 = in.readString();
    strMeasure9 = in.readString();
    strMeasure10 = in.readString();
    strMeasure11 = in.readString();
    strMeasure12 = in.readString();
    strMeasure13 = in.readString();
    strMeasure14 = in.readString();
    strMeasure15 = in.readString();
    strMeasure16 = in.readString();
    strMeasure17 = in.readString();
    strMeasure18 = in.readString();
    strMeasure19 = in.readString();
    strMeasure20 = in.readString();
    strSource = in.readString();
    dateModified = in.readString();
  }

  public String getIngredients(Context context) {
    StringBuilder ret = new StringBuilder();
    String format = "<i>%s</i> <b>%s</b><br/>\n";
    Meal meal = this;
    Class mealClass = Meal.class;

    for(int i = 1; i <= 15; i++) {
      try {
        Field fieldM = mealClass.getDeclaredField("strMeasure" + i);
        Field fieldI = mealClass.getDeclaredField("strIngredient" + i);
        String valueM = (String) fieldM.get(meal);
        String valueI = (String) fieldI.get(meal);

        if (valueI != null && valueI.compareTo("") != 0 ) {
          if(valueM == null)
            valueM = context.getString(R.string.qb);
          else
            valueM = valueM + ": ";
          ret.append(String.format(Locale.getDefault(), format, valueM, valueI));
        } else
          break;
      } catch (NoSuchFieldException | IllegalAccessException e) {
        e.printStackTrace();
      }
    }

    return ret.toString();
  }

  public boolean isFull() {
    return strInstructions != null;
  }

  public String getMealName() {
    return strMeal;
  }

  public String getStrMealThumb(){
    return strMealThumb;
  }

  public void setMealName(String meal){
    strMeal = meal;
  }

  public void setMealThumb(String thumb){
    strMealThumb = thumb;
  }




}
