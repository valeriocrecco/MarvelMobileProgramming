package it.smellsliketeamspirit.themealdbfragments.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import it.smellsliketeamspirit.themealdbfragments.entities.Meal;

public class MealListViewModel extends ViewModel {
  private MutableLiveData<List<Meal>> meals;
  public LiveData<List<Meal>> getMeals() {
    if(meals == null)
      meals = new MutableLiveData<>();
    return meals;
  }

  public void setMeals(List<Meal> meals) {
    this.meals.setValue(meals);
  }
}