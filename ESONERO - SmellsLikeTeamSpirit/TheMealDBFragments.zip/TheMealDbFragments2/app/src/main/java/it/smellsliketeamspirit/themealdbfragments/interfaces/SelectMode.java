package it.smellsliketeamspirit.themealdbfragments.interfaces;

public interface SelectMode {
  void onSelect(int size);
}
