package it.smellsliketeamspirit.marvel_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import it.smellsliketeamspirit.marvel_project.activities.RetrieveFavouriteHeroes;
import it.smellsliketeamspirit.marvel_project.activities.SeachChoice;
import it.smellsliketeamspirit.marvel_project.activities.about;
import it.smellsliketeamspirit.marvel_project.activities.help;
import it.smellsliketeamspirit.marvel_project.database.MyAppDatabase;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView ivStar,ivSearch,ivHelp,ivlogo;

    public static MyAppDatabase myAppDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        myAppDatabase = Room.databaseBuilder(getApplicationContext(), MyAppDatabase.class, "marveldb").allowMainThreadQueries().fallbackToDestructiveMigration().build();

        ivStar = findViewById(R.id.ivFav);
        ivSearch = findViewById(R.id.ivSearch);
        ivHelp = findViewById(R.id.ivHelp);
        ivlogo = findViewById(R.id.ivLogo);


        ivStar.setOnClickListener(this);
        ivHelp.setOnClickListener(this);
        ivSearch.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.ivHelp){
            Intent helpIntent = new Intent(MainActivity.this, help.class);
            startActivity(helpIntent);
        }

        if(v.getId() == R.id.ivSearch) {
            Intent searchIntent=new Intent(MainActivity.this, SeachChoice.class);
            startActivity(searchIntent);
        }
        if(v.getId() == R.id.ivFav){
            Intent searchIntent=new Intent(MainActivity.this, RetrieveFavouriteHeroes.class);
            startActivity(searchIntent);
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent=new Intent(this, about.class);
            startActivity(infoIntent);
            //fai qualcosa
        }
        return super.onContextItemSelected(item);
    }




}
