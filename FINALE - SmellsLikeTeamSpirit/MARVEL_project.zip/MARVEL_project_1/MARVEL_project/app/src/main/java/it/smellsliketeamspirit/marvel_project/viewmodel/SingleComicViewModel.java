package it.smellsliketeamspirit.marvel_project.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

@SuppressWarnings("unused")
public class SingleComicViewModel extends ViewModel{
    private MutableLiveData<it.smellsliketeamspirit.marvel_project.entities.Comic> info;

    public LiveData<it.smellsliketeamspirit.marvel_project.entities.Comic> getInfo() {
        if(info == null)
            info = new MutableLiveData<>();
        return info;
    }

    public void loadInfo(it.smellsliketeamspirit.marvel_project.entities.Comic comic) {
        if(info == null)
            info = new MutableLiveData<>();
        info.setValue(comic);
    }
}
