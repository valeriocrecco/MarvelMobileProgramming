package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

@SuppressWarnings("unused")
@org.parceler.Parcel
public class Hero implements Parcelable {

    private int id;
    private String name;
    private String description;
    private String resURI;
    private MarvelImage imgHero;
    private String collectionURIComics;
    private String collectionURISeries;
    private String collectionURIStories;
    private String collectionURIEvents;
    private int pref_Hero = 0;

    public Hero() {

    }

    public Hero(String resURI, String name) {
        this.resURI = resURI;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public MarvelImage getImgHero() {
        return imgHero;
    }

    public void setImgHero(MarvelImage imgHero) {
        this.imgHero = imgHero;
    }

    public String getCollectionURIComics() {
        return collectionURIComics;
    }

    public void setCollectionURIComics(String collectionURI) {
        this.collectionURIComics = collectionURI;
    }

    public String getCollectionURISeries() {
        return collectionURISeries;
    }

    public void setCollectionURISeries(String collectionURISeries) {
        this.collectionURISeries = collectionURISeries;
    }

    public String getCollectionURIStories() {
        return collectionURIStories;
    }

    public void setCollectionURIStories(String collectionURIStories) {
        this.collectionURIStories = collectionURIStories;
    }

    public String getCollectionURIEvents() {
        return collectionURIEvents;
    }

    public void setCollectionURIEvents(String collectionURIEvents) {
        this.collectionURIEvents = collectionURIEvents;
    }

    public static final Creator<Hero> CREATOR = new Creator<Hero>() {
        @Override
        public Hero createFromParcel(Parcel in) {
            return new Hero(in);
        }

        @Override
        public Hero[] newArray(int size) {
            return new Hero[size];
        }
    };

    private Hero(Parcel in) {
        id = in.readInt();
        name = in.readString();
        description = in.readString();
        resURI = in.readString();
        imgHero = in.readParcelable(MarvelImage.class.getClassLoader());
        collectionURIComics = in.readString();
        collectionURISeries = in.readString();
        collectionURIStories = in.readString();
        collectionURIEvents = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(imgHero, flags);
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(resURI);
        dest.writeString(collectionURIComics);
        dest.writeString(collectionURISeries);
        dest.writeString(collectionURIStories);
        dest.writeString(collectionURIEvents);
    }

    public int getPref_Hero() {
        return pref_Hero;
    }

    public void setPref_Hero(int pref_Hero) {
        this.pref_Hero=pref_Hero;
    }
}
