package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import it.smellsliketeamspirit.marvel_project.R;

public class about extends AppCompatActivity implements View.OnClickListener {


    ImageButton ibInstagram,ibFacebook,ibYoutube,ibLinkedin,ibTwitter,ibPaypal,ibGplus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_activity1);

        ibInstagram = findViewById(R.id.ib_instagram);
        ibFacebook = findViewById(R.id.ib_facebook);
        ibYoutube = findViewById(R.id.ib_youtube);
        ibLinkedin = findViewById(R.id.ib_linkedin);
        ibTwitter = findViewById(R.id.ib_twitter);
        ibPaypal = findViewById(R.id.ib_paypal);
        ibGplus = findViewById(R.id.ib_googlep);

        ibInstagram.setOnClickListener(this);
        ibFacebook.setOnClickListener(this);
        ibYoutube.setOnClickListener(this);
        ibLinkedin.setOnClickListener(this);
        ibTwitter.setOnClickListener(this);
        ibPaypal.setOnClickListener(this);
        ibGplus.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.ib_instagram) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://www.instagram.com/?hl=it"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_facebook) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://it-it.facebook.com"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_youtube) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://www.youtube.com/?gl=IT&hl=it"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_twitter) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://twitter.com/explore"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_linkedin) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://it.linkedin.com"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_googlep) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://gsuite.google.com/intl/it/features/?utm_source=google&utm_source=google&utm_medium=cpc&utm_medium=cpc&utm_campaign=emea-it-all-it-dr-bkws-all-lptestctrl-trial-e-t1-1007172&utm_campaign=emea-it-all-it-dr-bkws-all-super-trial-e-t1-1009147&utm_content=text-ad-none-none-DEV_c-CRE_156035602706-ADGP_Hybrid%20%7C%20AW%20SEM%20%7C%20BKWS%20~%20EXA_M:1_IT_IT_G%20Suite_GSB01_g%20suite-KWID_43700014378896705-kwd-7564271891-userloc_1008738&utm_content=text-ad-none-none-DEV_c-CRE_156035602706-ADGP_Hybrid%20%7C%20AW%20SEM%20%7C%20BKWS%20~%20EXA_M:1_IT_IT_G%20Suite_GSB01_g%20suite-KWID_43700014378896705-kwd-7564271891-userloc_1008738&utm_term=KW_g%20suite-g&utm_term=KW_g%20suite-g&ds_rl=1244687&ds_rl=1259922&ds_rl=1244687&ds_rl=1259922&gclsrc=aw.ds&gclsrc=aw.ds&gclid=EAIaIQobChMI4qzxusC26gIVB-7tCh0yywGhEAAYASAAEgLQQPD_BwE"));
            startActivity(intent);
        }

        if(v.getId() == R.id.ib_paypal) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse("https://www.paypal.com"));
            startActivity(intent);
        }


    }
}
