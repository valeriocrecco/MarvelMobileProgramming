package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

@SuppressWarnings("unused")
public class MarvelImage implements Parcelable {

    private String path;
    private String ext;

    public MarvelImage(String path, String ext) {
        this.path = path;
        this.ext = ext;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public String getFullPathMedium() {
        String fullPath = path + "/standard_xlarge" + "." + ext;
        return fullPath;
    }

    public String getFullPathLarge(){
        String fullPath = path + "/standard_fantastic" + "." + ext;
        return fullPath;
    }

    public static final Creator<MarvelImage> CREATOR = new Creator<MarvelImage>() {
        @Override
        public MarvelImage createFromParcel(Parcel in) {
            return new MarvelImage(in);
        }

        @Override
        public MarvelImage[] newArray(int size) {
            return new MarvelImage[size];
        }
    };

    private MarvelImage(Parcel in) {
        path = in.readString();
        ext = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(path);
        dest.writeString(ext);
    }

}
