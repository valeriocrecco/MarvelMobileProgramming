package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import java.util.Objects;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentComicDetail;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentComicList;

public class SearchComics extends AppCompatActivity {

    Fragment fragmentComics;
    Fragment fragmentComicsDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int orientation = this.getResources().getConfiguration().orientation;
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home);

        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            portrait();
        } else {
            landscape();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }

    private void removeFragments() {

        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentComics)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentComicsDetail)
                .commit();
    }

    private void portrait() {
        fragmentComicsDetail = new FragmentComicDetail();
        fragmentComics = new FragmentComicList(this::switchFragment);
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.homeFrame, fragmentComics)
                .commit();
    }

    private void landscape() {
        fragmentComicsDetail = new FragmentComicDetail();
        fragmentComics = new FragmentComicList();
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.detailFrame, fragmentComicsDetail)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentComics)
                .commit();
    }

    void switchFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.homeFrame, fragmentComicsDetail)
                .addToBackStack("MASTER")
                .commit();
    }
}