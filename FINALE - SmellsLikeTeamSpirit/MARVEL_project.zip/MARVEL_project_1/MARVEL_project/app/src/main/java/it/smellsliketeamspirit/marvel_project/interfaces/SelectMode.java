package it.smellsliketeamspirit.marvel_project.interfaces;
@SuppressWarnings("unused")
public interface SelectMode {
    void onSelect(int size);
}
