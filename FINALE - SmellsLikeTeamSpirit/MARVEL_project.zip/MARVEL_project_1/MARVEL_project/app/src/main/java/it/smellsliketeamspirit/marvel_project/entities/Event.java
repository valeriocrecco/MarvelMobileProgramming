package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
@SuppressWarnings("unused")
public class Event implements Parcelable {

    private  int id;
    private String title;
    private String description;
    private String resURI;
    private MarvelImage marvelImage;
    private ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators;
    private String collectionURICharacters;
    private ArrayList<String> charactersName;
    private String collectionURIStories;
    private String collectionURIComics;
    private String collectionURISeries;
    private String nextEvent;
    private String prevEvent;

    public Event() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public MarvelImage getMarvelImage() {
        return marvelImage;
    }

    public void setMarvelImage(MarvelImage marvelImage) {
        this.marvelImage = marvelImage;
    }

    public ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> getCreators() {
        return creators;
    }

    public void setCreators(ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators) {
        this.creators = creators;
    }

    public String getCollectionURICharacters() {
        return collectionURICharacters;
    }

    public void setCollectionURICharacters(String collectionURICharacters) {
        this.collectionURICharacters = collectionURICharacters;
    }

    public ArrayList<String> getCharactersName() {
        return charactersName;
    }

    public void setCharactersName(ArrayList<String> charactersName) {
        this.charactersName = charactersName;
    }

    public String getCollectionURIStories() {
        return collectionURIStories;
    }

    public void setCollectionURIStories(String collectionURIStories) {
        this.collectionURIStories = collectionURIStories;
    }

    public String getCollectionURIComics() {
        return collectionURIComics;
    }

    public void setCollectionURIComics(String collectionURIComics) {
        this.collectionURIComics = collectionURIComics;
    }

    public String getCollectionURISeries() {
        return collectionURISeries;
    }

    public void setCollectionURISeries(String collectionURISeries) {
        this.collectionURISeries = collectionURISeries;
    }

    public String getNextEvent() {
        return nextEvent;
    }

    public void setNextEvent(String nextEvent) {
        this.nextEvent = nextEvent;
    }

    public String getPrevEvent() {
        return prevEvent;
    }

    public void setPrevEvent(String prevEvent) {
        this.prevEvent = prevEvent;
    }

    public static final Creator<Event> CREATOR = new Creator<Event>() {
        @Override
        public Event createFromParcel(Parcel in) {
            return new Event(in);
        }

        @Override
        public Event[] newArray(int size) {
            return new Event[size];
        }
    };

    private Event(Parcel in) {
        id = in.readInt();
        title = in.readString();
        description = in.readString();
        resURI = in.readString();
        nextEvent = in.readString();
        prevEvent = in.readString();
        collectionURICharacters = in.readString();
        collectionURIStories = in.readString();
        collectionURISeries = in.readString();
        collectionURIComics = in.readString();
        marvelImage = in.readParcelable(MarvelImage.class.getClassLoader());
        in.readTypedList(creators, it.smellsliketeamspirit.marvel_project.entities.Creator.CREATOR);
        in.readStringList(charactersName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(marvelImage, flags);
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(resURI);
        dest.writeString(nextEvent);
        dest.writeString(prevEvent);
        dest.writeString(collectionURICharacters);
        dest.writeString(collectionURIStories);
        dest.writeString(collectionURIComics);
        dest.writeString(collectionURISeries);
        dest.writeTypedList(creators);
        dest.writeStringList(charactersName);
    }
}
