package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import it.smellsliketeamspirit.marvel_project.R;

public class help extends AppCompatActivity implements View.OnClickListener {
    EditText et_msg,et_subject;
    Button btnSend;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_activity1);

        et_msg=findViewById(R.id.et_msg);
        et_subject=findViewById(R.id.et_subject);
        btnSend=findViewById(R.id.btn_send);
        TextView tvDescrizione = findViewById(R.id.tv_des);
        tvDescrizione.setMovementMethod(LinkMovementMethod.getInstance());
        btnSend.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        sendMail();
    }

    private void sendMail() {
        String subject=et_subject.getText().toString();
        String message=et_msg.getText().toString();
        String[] devMail={"developer@mail.com"};
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL,devMail);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,message);

        intent.setType("message/rfc822");  //mi permette di aprire solo i clients email
        startActivity(Intent.createChooser(intent,"Choose an email client"));
    }



}
