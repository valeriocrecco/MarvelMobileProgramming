package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;

public class SeachChoice extends AppCompatActivity implements View.OnClickListener{

    ImageView searchHero, searchComic;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_search);

        searchHero = findViewById(R.id.ivCharact);
        searchComic = findViewById(R.id.ivComics);

        searchHero.setOnClickListener(this);
        searchComic.setOnClickListener(this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu
        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.ivCharact){
            Intent searchHeroIntent = new Intent(SeachChoice.this, SearchHero.class);
            startActivity(searchHeroIntent);
        }

        if(v.getId() == R.id.ivComics) {
            Intent searchComicsIntent=new Intent(SeachChoice.this, SearchComics.class);
            startActivity(searchComicsIntent);
        }

    }
}
