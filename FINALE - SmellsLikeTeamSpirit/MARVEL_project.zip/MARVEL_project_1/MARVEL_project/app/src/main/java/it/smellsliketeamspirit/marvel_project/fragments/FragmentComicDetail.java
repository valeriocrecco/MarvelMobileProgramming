package it.smellsliketeamspirit.marvel_project.fragments;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.Comic;
import it.smellsliketeamspirit.marvel_project.viewmodel.SingleComicViewModel;
@SuppressWarnings("unused")
public class FragmentComicDetail extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_comic_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SingleComicViewModel cvm = new ViewModelProvider(requireActivity()).get(SingleComicViewModel.class);
        cvm.getInfo().observe(getViewLifecycleOwner(), item -> new Holder(view, item));
    }

    class Holder {
        final TextView tvComicName;
        final TextView tvComicDescription;
        final TextView tvComicPrice;
        final TextView tvComicPageNumber;
        final ImageView ivComic;

        Holder(View view, Comic comic) {
            view.findViewById(R.id.svBase).setVisibility(View.VISIBLE);
            tvComicName = view.findViewById(R.id.tvComicName);
            tvComicDescription = view.findViewById(R.id.tvComicDescription);
            tvComicPrice = view.findViewById(R.id.tvComicPrice);
            tvComicPageNumber = view.findViewById(R.id.tvComicPageNumber);
            ivComic = view.findViewById(R.id.ivComicRetr);

            fillLayout(comic);
        }

        @SuppressLint("SetTextI18n")
        void fillLayout(Comic comic) {
            tvComicName.setText(comic.getSeriesName().toUpperCase());
            if(comic.getDescription().equals("null") || comic.getDescription() == null){
                tvComicDescription.setText("Description not available");
            }else {
                tvComicDescription.setText(comic.getDescription());
            }

            tvComicPrice.setText("10€");
            tvComicPageNumber.setText(String.valueOf(comic.getPageCount()));

            ImageRequest request = new ImageRequest(comic.getMarvelImage().getFullPathLarge(), ivComic::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888, error -> ivComic.setImageResource(R.drawable.iv_logo));
            if(getActivity() != null) {
                RequestQueue queue = Volley.newRequestQueue(getActivity());
                queue.add(request);
            }
        }
    }
}
