package it.smellsliketeamspirit.marvel_project.entities;

import org.parceler.Parcel;

@SuppressWarnings("unused")
@Parcel
public class FavouriteHeroDetail {

    int id;
    String heroName;
    String heroDescription;
    String heroImg;

    public  FavouriteHeroDetail(){

    }

    public FavouriteHeroDetail(int id, String name, String desc, String img){
        this.id = id;
        this.heroName = name;
        this.heroDescription = desc;
        this.heroImg = img;
    }

    public int getHeroId() {
        return this.id;
    }

    public String getHeroDescription() {
        return heroDescription;
    }

    public void setHeroDescription(String heroDescription) {
        this.heroDescription=heroDescription;
    }


    public String getHeroName() {
        return heroName;
    }

    public void setHeroName(String heroName) {
        this.heroName=heroName;
    }


    public String getHeroImg() {
        return heroImg;
    }

    public void setHeroImg(String heroImg) {
        this.heroImg=heroImg;
    }


}
