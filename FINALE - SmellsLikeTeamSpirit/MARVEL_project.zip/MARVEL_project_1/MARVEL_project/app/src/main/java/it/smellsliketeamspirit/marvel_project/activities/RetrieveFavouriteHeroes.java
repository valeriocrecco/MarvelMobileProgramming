package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.parceler.Parcels;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.FavouriteHero;
import it.smellsliketeamspirit.marvel_project.entities.FavouriteHeroDetail;


public class RetrieveFavouriteHeroes extends AppCompatActivity {


    private List<FavouriteHero> heroesList;

    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrieve_pref_hero_list);

        setLayout();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }

    public void setLayout(){
        loadHeroes();
    }


    private void loadHeroes(){

        runOnUiThread(new Runnable() {
              public void run() {
                  List<FavouriteHero> heroes = MainActivity.myAppDatabase.myDAO().getHeroes();
                  getHeroesList(heroes);
              }
              private void getHeroesList(List<FavouriteHero> heroes) {
                RecyclerView recyclerView = findViewById(R.id.rv_Heroes);
                heroesList = heroes;
                RecyclerView.Adapter hAdapter = new MyAdapter(heroesList);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setAdapter(hAdapter);
              }
        });
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.Holder> implements View.OnClickListener {

        List<FavouriteHero> mDataset;

        MyAdapter(List<FavouriteHero> myDataset) {
            mDataset = myDataset;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            CardView cv = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.retrieved_hero, parent, false);
            cv.setOnClickListener(this);
            return new Holder(cv);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {

            FavouriteHero hero = mDataset.get(position);
            holder.tvHeroName.setText(mDataset.get(position).getName());

            holder.ivHeartList.setOnClickListener(((View v) -> runOnUiThread(() -> {
                MainActivity.myAppDatabase.myDAO().deleteHeroFromPrefs(hero);
                Toast.makeText(getApplicationContext(), R.string.toast2, Toast.LENGTH_LONG).show();
                setLayout();
            })));

            String drawableRes= mDataset.get(position).getImgHero();
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            try {
                URL url = new URL(drawableRes);
                holder.ivClickMe.setImageBitmap(BitmapFactory.decodeStream((InputStream)url.getContent()));
            } catch (IOException ignored) {

            }


        }




        @Override
        public int getItemCount() {
            return mDataset.size();
        }

        @Override
        public void onClick(View v) {

            TextView tv = v.findViewById(R.id.tvHeroName);
            FavouriteHero heroToShow;
            heroToShow = getHero(tv.getText().toString());

            FavouriteHeroDetail favouriteHeroDetail = new FavouriteHeroDetail(heroToShow.getId(), heroToShow.getName(), heroToShow.getDescription(), heroToShow.getImgHero());
            Parcelable parcelable = Parcels.wrap(favouriteHeroDetail);
            Intent intent = new Intent(RetrieveFavouriteHeroes.this, PrefHeroDetail.class);
            intent.putExtra("DATA_KEY", parcelable);
            startActivity(intent);
        }

        class Holder extends RecyclerView.ViewHolder{
            public  TextView tvHeroName;
            public ImageView ivClickMe;
            public ImageView ivHeartList;
            Holder(CardView cv){
                super(cv);
                tvHeroName = cv.findViewById(R.id.tvHeroName);
                ivClickMe = cv.findViewById(R.id.ivLogo);
                ivHeartList = cv.findViewById(R.id.ivHeartList);

            }



        }
    }

    private FavouriteHero getHero(String name) {

        FavouriteHero hero;
        hero = MainActivity.myAppDatabase.myDAO().getHero(name);
        return hero;

    }
}
