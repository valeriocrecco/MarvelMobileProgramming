package it.smellsliketeamspirit.marvel_project.requests;

import android.content.Context;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import it.smellsliketeamspirit.marvel_project.entities.*;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@SuppressWarnings("unused")
public abstract class StoryAPI implements Response.Listener<String> {

    private static final String TIME_STAMP = "1"; // NON TOCCARE QUESTO!!!
    private static final String APIKEY = "fed0a168e2fc7c65424b14a30b89b358";
    private static final String HASH = "671fc2069018eab3f9c5fe6549ba864a";
    private RequestQueue requestQueue;

    public abstract void fillLayout(List<Story> stories);

    protected StoryAPI(Context context) {
        Cache cache = new DiskBasedCache(context.getCacheDir(), 10 * 1024 * 1024); // 10 MB cache
        Network network = new BasicNetwork(new HurlStack());
        requestQueue = new RequestQueue(cache, network);
        requestQueue.start();
    }

    public void searchStoryByName(String s) {
        String url = "https://gateway.marvel.com/v1/public/stories?ts=%s&name=%s&apikey=%s&hash=%s";
        String urlSearch = String.format(Locale.getDefault(), url, TIME_STAMP, s, APIKEY, HASH);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, urlSearch, this, error -> {});
        requestQueue.add(stringRequest);
    }

    public void searchStoryByHeroId(String heroId) {
        String url = "https://gateway.marvel.com/v1/public/stories?limit=20&characters=%s&ts=1&apikey=fed0a168e2fc7c65424b14a30b89b358&hash=671fc2069018eab3f9c5fe6549ba864a";
        String urlSearch = String.format(Locale.getDefault(), url, heroId, TIME_STAMP,APIKEY, HASH);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urlSearch, this, error -> {});
        requestQueue.add(stringRequest);
    }

    @Override
    public void onResponse(String response) {

        ArrayList<Story> stories = new ArrayList<>();



        try {
            JSONObject jsonObjectResponse = new JSONObject(response);
            JSONObject jsonObjectData = jsonObjectResponse.getJSONObject("data");
            JSONArray jsonArrayResults = jsonObjectData.getJSONArray("results");

            for (int i=0; i < jsonArrayResults.length(); i++) {

                JSONObject object = jsonArrayResults.getJSONObject(i);

                Story story = new Story();
                story.setId(object.getInt("id"));
                story.setTitle(object.getString("title"));

                story.setDescription(object.getString("description"));
                story.setResURI(object.getString("resourceURI"));


                //mi prendo i dati di tutti i comics collegati alla storia
                JSONObject jsonObjectComics = object.getJSONObject("comics");
                JSONArray jsonArrayComics = jsonObjectComics.getJSONArray("items");
                ArrayList<Comic> comics = new ArrayList<>();
                for (int j=0; j < jsonArrayComics.length(); j++) {



                    JSONObject jsonObjectComic = jsonArrayComics.getJSONObject(j);
                    Comic comic = new Comic(
                            jsonObjectComic.getString("resourceURI"),
                            jsonObjectComic.getString("name")

                    );

                    comics.add(comic);
                }
                story.setComics(comics);

                //mi prendo i dati di tutte le serie collegate alla storia
                JSONObject jsonObjectSeries = object.getJSONObject("series");
                JSONArray jsonArraySeries = jsonObjectSeries.getJSONArray("items");
                ArrayList<Serie> series = new ArrayList<>();
                for (int j=0; j < jsonArraySeries.length(); j++) {


                    JSONObject jsonObjectSerie = jsonArraySeries.getJSONObject(j);
                    Serie ser = new Serie(
                            jsonObjectSerie.getString("resourceURI"),
                            jsonObjectSerie.getString("name")
                    );

                    series.add(ser);
                }
                story.setSeriesName(series);


                //mi prendo tutti i dati degli eroi collegati alla storia
                JSONObject jsonObjectCharacters = object.getJSONObject("characters");
                JSONArray jsonArrayCharacters = jsonObjectCharacters.getJSONArray("items");
                ArrayList<Hero> characters = new ArrayList<>();
                for (int j=0; j < jsonArrayCharacters.length(); j++) {


                    JSONObject jsonObjectCharacter = jsonArrayCharacters.getJSONObject(j);
                    Hero hero = new Hero(
                            jsonObjectCharacter.getString("resourceURI"),
                            jsonObjectCharacter.getString("name")

                    );


                    characters.add(hero);
                }
                story.setCharactersName(characters);


                //mi prendo tutti i creatori della storia
                JSONObject jsonObjectCreators = object.getJSONObject("creators");
                JSONArray jsonArrayCreators = jsonObjectCreators.getJSONArray("items");
                ArrayList<Creator> creators = new ArrayList<>();
                for (int j=0; j < jsonArrayCreators.length(); j++) {


                    JSONObject jsonObjectCreator = jsonArrayCreators.getJSONObject(j);
                    Creator creator = new Creator(
                            jsonObjectCreator.getString("resourceURI"),
                            jsonObjectCreator.getString("name")
                    );

                    creators.add(creator);
                }
                story.setCreators(creators);

                stories.add(story);
                fillLayout(stories);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
