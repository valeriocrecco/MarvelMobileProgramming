package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;


import java.util.Objects;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentHeroSeriesDetail;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentHeroSeriesList;

@SuppressWarnings("unused")
public class SearchHeroSeries extends AppCompatActivity {

    Fragment fragmentHeroSeriesList;
    Fragment fragmentHeroSeriesDetail;
    String idHero;
    String heroName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hero_series);


        idHero = getIntent().getStringExtra("idHERO");
        heroName = getIntent().getStringExtra("heroName");

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home);
        int orientation = this.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            portrait();
        }
        else {
            landscape();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }

    private void removeFragments() {
        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentHeroSeriesList)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentHeroSeriesDetail)
                .commit();
    }

    private void portrait() {
        fragmentHeroSeriesDetail = new FragmentHeroSeriesDetail();
        fragmentHeroSeriesList = new FragmentHeroSeriesList(this::switchFragment);
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroSeriesList)
                .commit();
    }

    private void landscape() {
        fragmentHeroSeriesDetail = new FragmentHeroSeriesDetail();
        fragmentHeroSeriesList = new FragmentHeroSeriesList();
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.detailFrame, fragmentHeroSeriesDetail)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroSeriesList)
                .commit();
    }

    void switchFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroSeriesDetail)
                .addToBackStack("MASTER")
                .commit();
    }


    public String getHeroSeriesID(){
        return idHero;
    }


    public String getHeroName(){
        return heroName;
    }


}








