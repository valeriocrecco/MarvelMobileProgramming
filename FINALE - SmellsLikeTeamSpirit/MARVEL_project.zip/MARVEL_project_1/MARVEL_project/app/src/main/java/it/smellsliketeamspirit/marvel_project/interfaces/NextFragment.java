package it.smellsliketeamspirit.marvel_project.interfaces;
@SuppressWarnings("unused")
public interface NextFragment {
    void nextFragment();
}
