package it.smellsliketeamspirit.marvel_project.fragments;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import it.smellsliketeamspirit.marvel_project.adapters.ComicsAdapter;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.Comic;
import it.smellsliketeamspirit.marvel_project.interfaces.NextFragment;
import it.smellsliketeamspirit.marvel_project.interfaces.SelectMode;
import it.smellsliketeamspirit.marvel_project.requests.ComicAPI;
import it.smellsliketeamspirit.marvel_project.viewmodel.ComicsViewModel;
import it.smellsliketeamspirit.marvel_project.viewmodel.SingleComicViewModel;

import java.util.List;

@SuppressWarnings("unused")
public class FragmentComicList extends Fragment implements SelectMode{
    private ComicsAdapter comicAdapter;
    private RecyclerView rv;
    private ComicAPI api;
    private NextFragment nf;
    private SingleComicViewModel svm;
    private ComicsViewModel clm;




    public FragmentComicList() {
        // Required empty public constructor
    }

    public FragmentComicList(NextFragment nf) {
        this.nf = nf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_fumetti, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Holder holder = new Holder(view);
        clm = new ViewModelProvider(requireActivity()).get(ComicsViewModel.class);
        clm.getComics().observe(getViewLifecycleOwner(), holder::setList);
    }

    private void onClickAPICallBack(Comic comic) {
        svm = new ViewModelProvider(requireActivity()).get(SingleComicViewModel.class);
        svm.loadInfo(comic);

        if(nf != null) {
            nf.nextFragment();
        }
    }


    @Override
    public void onSelect(int size) {

    }


    class Holder implements View.OnClickListener, TextView.OnEditorActionListener{
        EditText etSearch;
        Button btnSearch;

        Holder(View v){
            etSearch = v.findViewById(R.id.etSearch);
            btnSearch = v.findViewById(R.id.btnSearch);
            etSearch.setOnEditorActionListener(this);
            btnSearch.setOnClickListener(this);

            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
            rv = v.findViewById(R.id.rvComics);
            rv.setLayoutManager(layoutManager);
            if(getActivity() != null) {
                api = new ComicAPI(getActivity()) {
                    @Override
                    public void fillLayout(List<it.smellsliketeamspirit.marvel_project.entities.Comic> comics) {
                        comicAdapter = new ComicsAdapter(getActivity(), comics, FragmentComicList.this) {
                            @Override
                            public void onClickAdapterCallBack(Comic comic) {
                                onClickAPICallBack(comic);
                            }
                        };
                        rv.setAdapter(comicAdapter);
                        clm.setComics(comicAdapter.getComics());
                    }
                };
            }
            if(getContext() != null) {
                Drawable drw = ContextCompat.getDrawable(getContext(), R.drawable.my_divider);
                if (drw != null) {
                    DividerItemDecoration itemDecorator = new DividerItemDecoration(getContext(),
                            DividerItemDecoration.VERTICAL);
                    itemDecorator.setDrawable(drw);
                    rv.addItemDecoration(itemDecorator);

                }
            }
        }

        private void search() {
            api.searchComicsByTitleStartsWith(etSearch.getText().toString());
        }

        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || actionId == EditorInfo.IME_ACTION_DONE) {
                search();

                return false;
            }
            return false;
        }

        @Override
        public void onClick(View v) {
            search();
        }

        void setList(List<Comic> comics) {
            if (comics == null)
                return;
            if(getActivity() != null) {
                comicAdapter = new ComicsAdapter(getActivity(), comics, FragmentComicList.this) {
                    @Override
                    public void onClickAdapterCallBack(Comic comic) {
                        onClickAPICallBack(comic);
                    }
                };
                rv.setAdapter(comicAdapter);
            }
        }

    }

}