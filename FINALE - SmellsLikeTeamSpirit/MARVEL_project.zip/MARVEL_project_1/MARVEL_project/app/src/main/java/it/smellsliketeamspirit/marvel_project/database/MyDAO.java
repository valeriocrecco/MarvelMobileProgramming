package it.smellsliketeamspirit.marvel_project.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import it.smellsliketeamspirit.marvel_project.entities.FavouriteHero;

@Dao
public interface MyDAO {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addHero(FavouriteHero hero);

    @Query("UPDATE heroes SET pref_hero = :value WHERE name = :name")
    void update(int value, String name);

    @Delete
    void deleteHeroFromPrefs(FavouriteHero name);

    @Query("select pref_hero from heroes where name = :name")
    int getPref(String name);

    @Query("select * from heroes where name = :name")
    FavouriteHero getHero(String name);

    @Query("select * from heroes")
    List<FavouriteHero> getHeroes();
}
