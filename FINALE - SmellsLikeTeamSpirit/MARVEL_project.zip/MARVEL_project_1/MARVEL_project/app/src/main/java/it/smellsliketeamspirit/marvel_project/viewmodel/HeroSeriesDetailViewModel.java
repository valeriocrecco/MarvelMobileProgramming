package it.smellsliketeamspirit.marvel_project.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import it.smellsliketeamspirit.marvel_project.entities.Serie;


@SuppressWarnings("unused")
public class HeroSeriesDetailViewModel extends ViewModel {

    private MutableLiveData<Serie> info;

    public LiveData<Serie> getInfo() {
        if(info == null)
            info = new MutableLiveData<>();
        return info;
    }

    public void loadInfo(Serie serie) {
        if(info == null)
            info = new MutableLiveData<>();
        info.setValue(serie);
    }
}
