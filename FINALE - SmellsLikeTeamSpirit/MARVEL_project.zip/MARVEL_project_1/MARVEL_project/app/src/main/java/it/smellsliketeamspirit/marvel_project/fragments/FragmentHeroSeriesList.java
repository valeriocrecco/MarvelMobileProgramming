package it.smellsliketeamspirit.marvel_project.fragments;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.activities.SearchHeroSeries;
import it.smellsliketeamspirit.marvel_project.adapters.HeroSerieAdapter;
import it.smellsliketeamspirit.marvel_project.entities.Serie;
import it.smellsliketeamspirit.marvel_project.interfaces.NextFragment;
import it.smellsliketeamspirit.marvel_project.interfaces.SelectMode;
import it.smellsliketeamspirit.marvel_project.requests.SerieAPI;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroSeriesDetailViewModel;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroSeriesListViewModel;

@SuppressWarnings("unused")
public class FragmentHeroSeriesList extends Fragment implements SelectMode {

    private HeroSerieAdapter heroSerieAdapter;
    private RecyclerView rv;
    private SerieAPI sapi;
    private NextFragment nf;
    private HeroSeriesListViewModel hlvm;
    private HeroSeriesDetailViewModel hvm;
    private String idSeriesHero;
    private String heroName;

    public FragmentHeroSeriesList() {

    }

    public FragmentHeroSeriesList(NextFragment nf) {
        this.nf = nf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        SearchHeroSeries searchHeroSeries = (SearchHeroSeries)getActivity();
        idSeriesHero = searchHeroSeries.getHeroSeriesID();
        heroName = searchHeroSeries.getHeroName();
        return inflater.inflate(R.layout.fragment_hero_series_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Holder holder = new Holder(view);
        hlvm = new ViewModelProvider(requireActivity()).get(HeroSeriesListViewModel.class);
        hlvm.getSeries().observe(getViewLifecycleOwner(), holder::setList);
    }

    private void onClickAPICallBack(Serie serie) {
        hvm = new ViewModelProvider(requireActivity()).get(HeroSeriesDetailViewModel.class);
        hvm.loadInfo(serie);

        if (nf != null) {
            nf.nextFragment();
        }
    }

    @Override
    public void onStop() {
        if(heroSerieAdapter != null)
            hlvm.setSeries(heroSerieAdapter.getSeries());
        super.onStop();
    }

    @Override
    public void onSelect(int size) {

    }


    class Holder implements View.OnClickListener, TextView.OnEditorActionListener, RadioGroup.OnCheckedChangeListener {

        EditText etSearchSerie;
        Button btnSearchSeries;
        RadioGroup radioGroupSearchSeries;

        Holder(View fl) {

            etSearchSerie = fl.findViewById(R.id.etSearchSeries);
            btnSearchSeries = fl.findViewById(R.id.btnSearchSeries);
            radioGroupSearchSeries = fl.findViewById(R.id.rd_choice_Serie);

            radioGroupSearchSeries.setOnCheckedChangeListener(this);
            etSearchSerie.setText(heroName);
            etSearchSerie.setOnEditorActionListener(this);
            btnSearchSeries.setOnClickListener(this);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
            rv = fl.findViewById(R.id.rvSeriesList);
            rv.setLayoutManager(layoutManager);


            if(getActivity() != null) {
                sapi = new SerieAPI(getActivity()) {
                    public void fillLayout(List<Serie> series) {
                        heroSerieAdapter = new HeroSerieAdapter(getActivity(), series, FragmentHeroSeriesList.this) {
                            @Override
                            public void onClickAdapterCallBack(Serie serie) {
                                onClickAPICallBack(serie);
                            }


                        };
                        rv.setAdapter(heroSerieAdapter);
                        hlvm.setSeries(heroSerieAdapter.getSeries());

                    }

                };
            }

            if(getContext() != null) {
                Drawable drw = ContextCompat.getDrawable(getContext(), R.drawable.my_divider);
                if (drw != null) {
                    DividerItemDecoration itemDecorator = new DividerItemDecoration(getContext(),
                            DividerItemDecoration.VERTICAL);
                    itemDecorator.setDrawable(drw);
                    rv.addItemDecoration(itemDecorator);
                }
            }
        }

        private void retriveAllSeriesOfACharacterByID() {
            sapi.searchSeriesByHeroID(idSeriesHero);
        }

        private void searchSerieByName() {
            sapi.searchSeriesByTitleStartsWith(etSearchSerie.getText().toString());
        }

        private void searchAllSeries(){
            sapi.searchSeries();
        }


        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                int checkedId = radioGroupSearchSeries.getCheckedRadioButtonId();
                if(checkedId == -1){
                    //no radio button are
                }else{
                    findRadioButton(checkedId);
                }
                return false;
            }
            return false;
        }

        private void findRadioButton(int checkedId){
            switch(checkedId){
                case R.id.rb_retreve_all:
                    retriveAllSeriesOfACharacterByID();
                    break;

                case R.id.rb_find_serie:
                    if(etSearchSerie.getText().toString().equals("")){
                        searchAllSeries();
                    }else{
                        searchSerieByName();
                    }

                    break;
            }
        }

        @Override
        public void onClick(View v) {

            int checkedId = radioGroupSearchSeries.getCheckedRadioButtonId();
            if(checkedId == -1){
                //no radio button are
            }else{
                findRadioButton(checkedId);
            }

        }

        void setList(List<Serie> series) {
            if (series == null)
                return;
            if(getActivity() != null) {
                heroSerieAdapter = new HeroSerieAdapter(getActivity(), series, FragmentHeroSeriesList.this) {
                    @Override
                    public void onClickAdapterCallBack(Serie serie) {
                        onClickAPICallBack(serie);
                    }
                };
                rv.setAdapter(heroSerieAdapter);
            }
        }


        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {

            switch(checkedId){
                case R.id.rb_retreve_all:
                    etSearchSerie.setText(heroName);
                    break;

                case R.id.rb_find_serie:
                    etSearchSerie.setText("");
                    etSearchSerie.setHint(R.string.cerca);
                    break;
            }
        }


    }
}
