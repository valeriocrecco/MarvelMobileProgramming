package it.smellsliketeamspirit.marvel_project.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import java.util.Objects;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentHeroDetail;
import it.smellsliketeamspirit.marvel_project.fragments.FragmentHeroList;

import it.smellsliketeamspirit.marvel_project.R;


public class SearchHero extends AppCompatActivity {

    Fragment fragmentHeroList;
    Fragment fragmentHeroDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_hero);

        int orientation = this.getResources().getConfiguration().orientation;
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home);
        if (orientation == Configuration.ORIENTATION_PORTRAIT){
            portrait();
        }
        else {
            landscape();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }

    private void removeFragments() {
        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentHeroList)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .remove(fragmentHeroDetail)
                .commit();
    }

    private void portrait() {
        fragmentHeroDetail = new FragmentHeroDetail();
        fragmentHeroList = new FragmentHeroList(this::switchFragment);
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroList)
                .commit();
    }

    private void landscape() {
        fragmentHeroDetail = new FragmentHeroDetail();
        fragmentHeroList = new FragmentHeroList();
        removeFragments();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.detailFrame, fragmentHeroDetail)
                .commit();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroList)
                .commit();
    }

    void switchFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.listFrame, fragmentHeroDetail)
                .addToBackStack("MASTER")
                .commit();
    }
}
