package it.smellsliketeamspirit.marvel_project.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import it.smellsliketeamspirit.marvel_project.entities.Serie;

@SuppressWarnings("unused")
public class HeroSeriesListViewModel extends ViewModel {

    private MutableLiveData<List<Serie>> series;

    public LiveData<List<Serie>> getSeries() {
        if(series == null)
            series = new MutableLiveData<>();
        return series;
    }

    public void setSeries(List<Serie> series) {
        this.series.setValue(series);
    }
}
