package it.smellsliketeamspirit.marvel_project.fragments;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.Serie;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroSeriesDetailViewModel;
@SuppressWarnings("unused")
public class FragmentHeroSeriesDetail extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_hero_series_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        HeroSeriesDetailViewModel hvm = new ViewModelProvider(requireActivity()).get(HeroSeriesDetailViewModel.class);
        hvm.getInfo().observe(getViewLifecycleOwner(), item -> new Holder(view, item));
    }

    class Holder {
        final TextView tvSerieName;
        final TextView tvDescription;
        final ImageView ivSerie;
        final TextView tvPrevSerie;
        final TextView tvNextSerie;


        Holder(View view, Serie serie) {
            view.findViewById(R.id.svBase).setVisibility(View.VISIBLE);
            tvSerieName = view.findViewById(R.id.tvHeroName);
            tvDescription = view.findViewById(R.id.tvDesciption);
            ivSerie = view.findViewById(R.id.ivHeroRetr);

            tvPrevSerie = view.findViewById(R.id.tvPrevSerie1);
            tvNextSerie = view.findViewById(R.id.tvNext1);

            fillLayout(serie);
        }

        @SuppressLint("SetTextI18n")
        void fillLayout(Serie serie) {
            tvSerieName.setText(serie.getTitle().toUpperCase());
            if(serie.getDescription().equals("null") || serie.getDescription() == null || serie.getDescription().equals("") || serie.getDescription().equals(" ")){
                tvDescription.setText("Description not available");
            }else{
                tvDescription.setText(serie.getDescription());
            }

            if(((serie.getPrevSerie() == null) || serie.getPrevSerie().equals("null")) || (serie.getPrevSerie().equals("")) || (serie.getPrevSerie().equals(" "))){
                tvPrevSerie.setText("Serie not available");
            }else{
                tvPrevSerie.setText(serie.getPrevSerie());
            }

            if((serie.getNextSerie() == null) || (serie.getNextSerie().equals("null")) || (serie.getNextSerie().equals("")) || (serie.getNextSerie().equals(" ")) ){
                tvNextSerie.setText("Serie not available");
            }else{
                tvNextSerie.setText(serie.getNextSerie());
            }


            ImageRequest request = new ImageRequest(serie.getMarvelImage().getFullPathLarge(), ivSerie::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888, error -> ivSerie.setImageResource(R.drawable.iv_logo));
            if(getActivity() != null) {
                RequestQueue queue = Volley.newRequestQueue(getActivity());
                queue.add(request);
            }
        }
    }
}
