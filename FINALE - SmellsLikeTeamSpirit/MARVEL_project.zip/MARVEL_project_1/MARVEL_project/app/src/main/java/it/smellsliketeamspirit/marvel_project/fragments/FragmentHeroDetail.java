package it.smellsliketeamspirit.marvel_project.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;


import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.activities.SearchHeroSeries;
import it.smellsliketeamspirit.marvel_project.activities.SearchStory;
import it.smellsliketeamspirit.marvel_project.entities.FavouriteHero;
import it.smellsliketeamspirit.marvel_project.entities.Hero;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroViewModel;

@SuppressWarnings("unused")
public class FragmentHeroDetail extends Fragment {

    int ret;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_hero_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        HeroViewModel hvm = new ViewModelProvider(requireActivity()).get(HeroViewModel.class);
        hvm.getInfo().observe(getViewLifecycleOwner(), item -> new Holder(view, item));
    }

    class Holder {
        final TextView tvHeroName;
        final TextView tvDescription;
        final ImageView ivHero;
        final ImageView ivHeart;
        final ImageView ivSeries;
        final ImageView ivStories;

        Holder(View view, Hero hero) {
            view.findViewById(R.id.svBase).setVisibility(View.VISIBLE);
            tvHeroName = view.findViewById(R.id.tvHeroName);
            tvDescription = view.findViewById(R.id.tvDesciption);
            ivHero = view.findViewById(R.id.ivHeroRetr);
            ivHeart = view.findViewById(R.id.ivHeart);
            ivSeries = view.findViewById(R.id.ibSeries);
            ivStories = view.findViewById(R.id.ibStories);


            ivHeart.setOnClickListener((v -> {
/*
                runOnUiThread(new Runnable() {
                    public void run() {

                    }
                });
*/

                if((ret = MainActivity.myAppDatabase.myDAO().getPref(hero.getName())) == 0){
                    FavouriteHero heroToSave = new FavouriteHero();
                    heroToSave.setId(hero.getId());
                    heroToSave.setName(hero.getName());
                    heroToSave.setImgHero(hero.getImgHero().getFullPathLarge());
                    heroToSave.setDescription(hero.getDescription());
                    heroToSave.setPref_hero(1);
                    MainActivity.myAppDatabase.myDAO().addHero(heroToSave);
                    ivHeart.setImageResource(R.drawable.heart);
                    Toast.makeText(getActivity(), R.string.toast1, Toast.LENGTH_LONG).show();

                }else{

                    if((ret = MainActivity.myAppDatabase.myDAO().getPref(hero.getName())) == 1){
                        ivHeart.setImageResource(R.drawable.heart_unselected);
                        MainActivity.myAppDatabase.myDAO().update(0, hero.getName());
                        FavouriteHero heroToDelete = new FavouriteHero();
                        heroToDelete.setName(hero.getName());
                        heroToDelete.setImgHero(hero.getImgHero().getFullPathLarge());
                        heroToDelete.setDescription(hero.getDescription());
                        heroToDelete.setPref_hero(0);
                        MainActivity.myAppDatabase.myDAO().deleteHeroFromPrefs(heroToDelete);
                        Toast.makeText(getActivity(),R.string.toast2, Toast.LENGTH_LONG).show();
                    }
                }

            }));

            ivSeries.setOnClickListener((v ->{

                String idHero = String.valueOf(hero.getId());
                String heroName = hero.getName();
                Intent intent = new Intent(getActivity(), SearchHeroSeries.class);
                intent.putExtra("idHERO", idHero);
                intent.putExtra("heroName", heroName);
                startActivity(intent);
            }));

            ivStories.setOnClickListener((v ->{

                String idHero = String.valueOf(hero.getId());
                Intent intent = new Intent(getActivity(), SearchStory.class);
                intent.putExtra("idHERO", idHero);
                startActivity(intent);
            }));

            fillLayout(hero);
        }

        @SuppressLint("SetTextI18n")
        void fillLayout(Hero hero) {
            tvHeroName.setText(hero.getName().toUpperCase());

            if(hero.getDescription().equals("null") || hero.getDescription() == null || hero.getDescription().equals(" ") || hero.getDescription().equals("")){
                tvDescription.setText("Description not available");
            }else {
                tvDescription.setText(hero.getDescription());
            }


            ImageRequest request = new ImageRequest(hero.getImgHero().getFullPathLarge(), ivHero::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888, error -> ivHero.setImageResource(R.drawable.iv_logo));
            if(getActivity() != null) {
                RequestQueue queue = Volley.newRequestQueue(getActivity());
                queue.add(request);
            }


            if((ret = MainActivity.myAppDatabase.myDAO().getPref(hero.getName())) == 0){
                ivHeart.setImageResource(R.drawable.heart_unselected);
            }else{
                ivHeart.setImageResource(R.drawable.heart);
            }

        }
    }
}
