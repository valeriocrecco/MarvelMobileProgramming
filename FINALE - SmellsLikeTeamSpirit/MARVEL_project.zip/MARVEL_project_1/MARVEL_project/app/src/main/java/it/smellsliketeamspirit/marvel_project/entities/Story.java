package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

@SuppressWarnings("unused")
public class Story implements Parcelable {

    private int id;
    private String title;
    private String resURI;
    private String description;
    private String type;
    private ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators = new ArrayList<>();
    private ArrayList<String> charactersName = new ArrayList<>();
    private String collectionURICharacters;
    private String collectionURISeries;
    private String collectionURIComics;
    private String collectionURIEvents;
    private String originalIssueResURI;
    private String originalIssueName;
    private MarvelImage marvelImage;
    private ArrayList<Comic> comics;
    private ArrayList<Serie> series;
    private ArrayList<Hero> characters;



    public Story() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public String getCollectionURISeries() {
        return collectionURISeries;
    }

    public void setCollectionURISeries(String collectionURISeries) {
        this.collectionURISeries = collectionURISeries;
    }

    public String getCollectionURIComics() {
        return collectionURIComics;
    }

    public void setCollectionURIComics(String collectionURIComics) {
        this.collectionURIComics = collectionURIComics;
    }

    public String getCollectionURIEvents() {
        return collectionURIEvents;
    }

    public void setCollectionURIEvents(String collectionURIEvents) {
        this.collectionURIEvents = collectionURIEvents;
    }

    public String getOriginalIssueResURI() {
        return originalIssueResURI;
    }

    public void setOriginalIssueResURI(String originalIssueResURI) {
        this.originalIssueResURI = originalIssueResURI;
    }

    public String getOriginalIssueName() {
        return originalIssueName;
    }

    public void setOriginalIssueName(String originalIssueName) {
        this.originalIssueName = originalIssueName;
    }

    public String getCollectionURICharacters() {
        return collectionURICharacters;
    }

    public void setCollectionURICharacters(String collectionURICharacters) {
        this.collectionURICharacters = collectionURICharacters;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<Serie> getSeriesName() {
        return series;
    }

    public void setSeriesName(ArrayList<Serie> seriesName) {
        this.series = seriesName;
    }


    public MarvelImage getMarvelImage() {
        return marvelImage;
    }

    public void setMarvelImage(MarvelImage marvelImage) {
        this.marvelImage = marvelImage;
    }

    public ArrayList<Comic> getComics() {
        return comics;
    }
    public void setComics(ArrayList<Comic> com) {
        this.comics = com;
    }


    public ArrayList<Hero> getCharactersName() {
        return characters;
    }

    public void setCharactersName(ArrayList<Hero> charactersName) {
        this.characters = charactersName;
    }
    public ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> getCreators() {
        return creators;
    }
    public void setCreators(ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators) {
        this.creators = creators;
    }


    public static final Creator<Story> CREATOR = new Creator<Story>() {
        @Override
        public Story createFromParcel(Parcel in) {
            return new Story(in);
        }

        @Override
        public Story[] newArray(int size) {
            return new Story[size];
        }
    };

    private Story(Parcel in) {
        id = in.readInt();
        title = in.readString();
        resURI = in.readString();
        type = in.readString();
        collectionURIComics = in.readString();
        collectionURISeries = in.readString();
        collectionURICharacters = in.readString();
        collectionURIEvents = in.readString();
        originalIssueName = in.readString();
        originalIssueResURI = in.readString();
        in.readTypedList(creators, it.smellsliketeamspirit.marvel_project.entities.Creator.CREATOR);
        in.readStringList(charactersName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(resURI);
        dest.writeString(type);
        dest.writeString(collectionURICharacters);
        dest.writeString(collectionURISeries);
        dest.writeString(collectionURIComics);
        dest.writeString(collectionURIEvents);
        dest.writeString(originalIssueResURI);
        dest.writeString(originalIssueName);
        dest.writeTypedList(creators);
        dest.writeStringList(charactersName);
    }
}
