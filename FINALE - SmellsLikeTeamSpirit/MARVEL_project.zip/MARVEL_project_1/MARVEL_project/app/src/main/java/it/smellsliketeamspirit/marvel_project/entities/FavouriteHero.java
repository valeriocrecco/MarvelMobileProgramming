package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@SuppressWarnings("unused")
@Entity(tableName="heroes")
public class FavouriteHero implements Parcelable {

    @ColumnInfo(name="_id")
    public int id;
    @PrimaryKey@NonNull
    @ColumnInfo(name="name")
    public String name;
    @ColumnInfo(name="description")
    public String description;
    @ColumnInfo(name="resURI")
    public String resURI;
    @ColumnInfo(name="imgHero")
    public String imgHero;
    @ColumnInfo(name="collectionURIComics")
    public String collectionURIComics;
    @ColumnInfo(name="collectionURISeries")
    public String collectionURISeries;
    @ColumnInfo(name="collectionURIStories")
    public String collectionURIStories;
    @ColumnInfo(name="collectionURIEvents")
    public String collectionURIEvents;
    @ColumnInfo(name="pref_hero")
    public int pref_hero = 0;

    public FavouriteHero() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public String getImgHero() {
        return imgHero;
    }

    public void setImgHero(String imgHero) {
        this.imgHero = imgHero;
    }

    public String getCollectionURIComics() {
        return collectionURIComics;
    }

    public void setCollectionURIComics(String collectionURI) {
        this.collectionURIComics = collectionURI;
    }

    public String getCollectionURISeries() {
        return collectionURISeries;
    }

    public void setCollectionURISeries(String collectionURISeries) {
        this.collectionURISeries = collectionURISeries;
    }

    public String getCollectionURIStories() {
        return collectionURIStories;
    }

    public void setCollectionURIStories(String collectionURIStories) {
        this.collectionURIStories = collectionURIStories;
    }

    public String getCollectionURIEvents() {
        return collectionURIEvents;
    }

    public void setCollectionURIEvents(String collectionURIEvents) {
        this.collectionURIEvents = collectionURIEvents;
    }

    public static final Creator<FavouriteHero> CREATOR = new Creator<FavouriteHero>() {
        @Override
        public FavouriteHero createFromParcel(Parcel in) {
            return new FavouriteHero(in);
        }

        @Override
        public FavouriteHero[] newArray(int size) {
            return new FavouriteHero[size];
        }
    };

    public FavouriteHero(Parcel in) {
        id = in.readInt();
        name = in.readString();
        description = in.readString();
        resURI = in.readString();
        imgHero = in.readString();
        collectionURIComics = in.readString();
        collectionURISeries = in.readString();
        collectionURIStories = in.readString();
        collectionURIEvents = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(imgHero);
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(resURI);
        dest.writeString(collectionURIComics);
        dest.writeString(collectionURISeries);
        dest.writeString(collectionURIStories);
        dest.writeString(collectionURIEvents);
    }

    public int getPref_hero() {
        return pref_hero;
    }

    public void setPref_hero(int pref_hero) {
        this.pref_hero=pref_hero;
    }
}
