package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

@SuppressWarnings("unused")
public class Comic implements Parcelable {

    private String id;
    private String title;
    private String description;
    private String format;
    private int pageCount;
    private String resURI;
    private String seriesResURI;
    private String seriesName;
    private int price;
    private MarvelImage marvelImage;
    private ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators;
    private String collectionURICharacters;
    private ArrayList<String> charactersName;
    private String collectionURIStories;
    private String collectionURIEvents;


    public Comic() {

    }


    public Comic(String resURI, String tit) {
        this.resURI = resURI;
        this.title = tit;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public String getSeriesResURI() {
        return seriesResURI;
    }

    public void setSeriesResURI(String seriesResURI) {
        this.seriesResURI = seriesResURI;
    }

    public String getSeriesName() {
        return seriesName;
    }

    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public MarvelImage getMarvelImage() {
        return marvelImage;
    }

    public void setMarvelImage(MarvelImage marvelImage) {
        this.marvelImage = marvelImage;
    }

    public ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> getCreators() {
        return creators;
    }

    public void setCreators(ArrayList<it.smellsliketeamspirit.marvel_project.entities.Creator> creators) {
        this.creators = creators;
    }

    public String getCollectionURICharacters() {
        return collectionURICharacters;
    }

    public void setCollectionURICharacters(String collectionURICharacters) {
        this.collectionURICharacters = collectionURICharacters;
    }

    public ArrayList<String> getCharactersName() {
        return charactersName;
    }

    public void setCharactersName(ArrayList<String> charactersName) {
        this.charactersName = charactersName;
    }

    public String getCollectionURIStories() {
        return collectionURIStories;
    }

    public void setCollectionURIStories(String collectionURIStories) {
        this.collectionURIStories = collectionURIStories;
    }

    public String getCollectionURIEvents() {
        return collectionURIEvents;
    }

    public void setCollectionURIEvents(String collectionURIEvents) {
        this.collectionURIEvents = collectionURIEvents;
    }

    public static final Creator<Comic> CREATOR = new Creator<Comic>() {
        @Override
        public Comic createFromParcel(Parcel in) {
            return new Comic(in);
        }

        @Override
        public Comic[] newArray(int size) {
            return new Comic[size];
        }
    };

    private Comic(Parcel in) {
        id = in.readString();
        title = in.readString();
        description = in.readString();
        format = in.readString();
        pageCount = in.readInt();
        resURI = in.readString();
        price = in.readInt();
        seriesResURI = in.readString();
        seriesName = in.readString();
        collectionURICharacters = in.readString();
        collectionURIStories = in.readString();
        collectionURIEvents = in.readString();
        marvelImage = in.readParcelable(MarvelImage.class.getClassLoader());
        in.readTypedList(creators, it.smellsliketeamspirit.marvel_project.entities.Creator.CREATOR);
        in.readStringList(charactersName);
    }


    @Override
    public int describeContents() {
         return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(marvelImage, flags);
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(format);
        dest.writeInt(pageCount);
        dest.writeString(resURI);
        dest.writeInt(price);
        dest.writeString(seriesResURI);
        dest.writeString(seriesName);
        dest.writeString(collectionURICharacters);
        dest.writeString(collectionURIStories);
        dest.writeString(collectionURIEvents);
        dest.writeTypedList(creators);
        dest.writeStringList(charactersName);
    }
}
