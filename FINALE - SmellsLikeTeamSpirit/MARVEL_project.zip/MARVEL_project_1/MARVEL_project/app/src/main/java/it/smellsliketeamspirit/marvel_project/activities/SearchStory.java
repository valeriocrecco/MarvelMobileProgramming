package it.smellsliketeamspirit.marvel_project.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.Comic;
import it.smellsliketeamspirit.marvel_project.entities.Creator;
import it.smellsliketeamspirit.marvel_project.entities.Hero;
import it.smellsliketeamspirit.marvel_project.entities.Serie;
import it.smellsliketeamspirit.marvel_project.entities.Story;

public class SearchStory extends AppCompatActivity {

    int length = 0;
    String creatorList = "";
    String idHero;


    ArrayList<Creator> creators = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_story);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home);
        idHero = getIntent().getStringExtra("idHERO");
        new Holder();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }
    // ------------------------------------------------------------------------------------------ //

    // VolleyStories - BEGIN
    abstract class VolleyStories implements Response.ErrorListener, Response.Listener<String> {

        abstract void fill(List<Story> cnt);

        private static final String TIME_STAMP = "1"; // NON TOCCARE QUESTO!!!
        private static final String APIKEY = "fed0a168e2fc7c65424b14a30b89b358";
        private static final String HASH = "671fc2069018eab3f9c5fe6549ba864a";

        public void searchStoryByHeroId(String heroId) {
            String url = "https://gateway.marvel.com/v1/public/stories?limit=20&characters=%s&ts=1&apikey=fed0a168e2fc7c65424b14a30b89b358&hash=671fc2069018eab3f9c5fe6549ba864a";
            String urlSearch = String.format(Locale.getDefault(), url, heroId, TIME_STAMP,APIKEY, HASH);
            apiCall(urlSearch);
        }


        private void apiCall(String url) {
            RequestQueue requestQueue;
            requestQueue = Volley.newRequestQueue(SearchStory.this);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, this, this);
            requestQueue.add(stringRequest);
        }

        @Override
        public void onErrorResponse(VolleyError error) {
        }

        @Override
        public void onResponse(String response) {
            ArrayList<Story> stories = new ArrayList<>();



            try {
                JSONObject jsonObjectResponse = new JSONObject(response);
                JSONObject jsonObjectData = jsonObjectResponse.getJSONObject("data");
                JSONArray jsonArrayResults = jsonObjectData.getJSONArray("results");

                for (int i=0; i < jsonArrayResults.length(); i++) {

                    JSONObject object = jsonArrayResults.getJSONObject(i);

                    Story story = new Story();
                    story.setId(object.getInt("id"));
                    story.setTitle(object.getString("title"));

                    story.setDescription(object.getString("description"));
                    story.setResURI(object.getString("resourceURI"));


                    //mi prendo i dati di tutti i comics collegati alla storia
                    JSONObject jsonObjectComics = object.getJSONObject("comics");
                    JSONArray jsonArrayComics = jsonObjectComics.getJSONArray("items");
                    ArrayList<Comic> comics = new ArrayList<>();
                    for (int j=0; j < jsonArrayComics.length(); j++) {



                        JSONObject jsonObjectComic = jsonArrayComics.getJSONObject(j);
                        Comic comic = new Comic(
                                jsonObjectComic.getString("resourceURI"),
                                jsonObjectComic.getString("name")

                        );

                        comics.add(comic);
                    }
                    story.setComics(comics);

                    //mi prendo i dati di tutte le serie collegate alla storia
                    JSONObject jsonObjectSeries = object.getJSONObject("series");
                    JSONArray jsonArraySeries = jsonObjectSeries.getJSONArray("items");
                    ArrayList<Serie> series = new ArrayList<>();
                    for (int j=0; j < jsonArraySeries.length(); j++) {


                        JSONObject jsonObjectSerie = jsonArraySeries.getJSONObject(j);
                        Serie ser = new Serie(
                                jsonObjectSerie.getString("resourceURI"),
                                jsonObjectSerie.getString("name")
                        );

                        series.add(ser);
                    }
                    story.setSeriesName(series);


                    //mi prendo tutti i dati degli eroi collegati alla storia
                    JSONObject jsonObjectCharacters = object.getJSONObject("characters");
                    JSONArray jsonArrayCharacters = jsonObjectCharacters.getJSONArray("items");
                    ArrayList<Hero> characters = new ArrayList<>();
                    for (int j=0; j < jsonArrayCharacters.length(); j++) {


                        JSONObject jsonObjectCharacter = jsonArrayCharacters.getJSONObject(j);
                        Hero hero = new Hero(
                                jsonObjectCharacter.getString("resourceURI"),
                                jsonObjectCharacter.getString("name")

                        );


                        characters.add(hero);
                    }
                    story.setCharactersName(characters);


                    //mi prendo tutti i creatori della storia
                    JSONObject jsonObjectCreators = object.getJSONObject("creators");
                    JSONArray jsonArrayCreators = jsonObjectCreators.getJSONArray("items");
                    ArrayList<Creator> creators = new ArrayList<>();
                    for (int j=0; j < jsonArrayCreators.length(); j++) {


                        JSONObject jsonObjectCreator = jsonArrayCreators.getJSONObject(j);
                        Creator creator = new Creator(
                                jsonObjectCreator.getString("resourceURI"),
                                jsonObjectCreator.getString("name")
                        );

                        creators.add(creator);
                    }
                    story.setCreators(creators);

                    stories.add(story);
                    fill(stories);


                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }
    // VolleyStories - END

    // ------------------------------------------------------------------------------------------ //

    // StoryAdapter - BEGIN
    private class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.Holder> implements View.OnClickListener {

        private final List<Story> stories;

        StoryAdapter(List<Story> all) {
            stories = all;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            CardView cl;
            cl = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.row_story, parent, false);
            cl.setOnClickListener(this);


            return new Holder(cl);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void onBindViewHolder(@NonNull StoryAdapter.Holder holder, int position) {

            int i;

            Story story = stories.get(position);
            holder.tvName.setText(story.getTitle());

            creators = story.getCreators();
            length = creators.size();

            if(length == 0){
                holder.tvCreators.setText("Creators not available");
            }else{
                for(i = 0; i < length; i++){
                    creatorList = creatorList.concat(creators.get(i).getName());
                    if(i == length-1){
                        creatorList = creatorList.concat(".");
                    }else{
                        creatorList = creatorList.concat(", ");
                    }

                }
                holder.tvCreators.setText(creatorList);
                creatorList = "";
            }
        }

        @Override
        public int getItemCount() {
            return stories.size();
        }

        @Override
        public void onClick(View v) {

        }

        class Holder extends RecyclerView.ViewHolder {

            final TextView tvName;
            final TextView tvCreators;


            Holder(@NonNull View itemView) {
                super(itemView);
                tvName=itemView.findViewById(R.id.tvName);
                tvCreators=itemView.findViewById(R.id.tvCreator1);
            }
        }

    }
    // StoriesAdapter - END

    // ------------------------------------------------------------------------------------------ //

    // Holder - BEGIN
    class Holder {


        final RecyclerView rvStories;
        final VolleyStories vcModel;

        Holder() {

            rvStories = findViewById(R.id.rvStoriesList);

            this.vcModel = new VolleyStories() {
                @Override
                void fill(List<Story> cnt) {
                    fillList(cnt);
                }

                private void fillList(List<Story> cnt) {
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchStory.this);
                    rvStories.setLayoutManager(layoutManager);
                    StoryAdapter storiesAdapter = new StoryAdapter(cnt);
                    rvStories.setAdapter(storiesAdapter);
                }

            };

            vcModel.searchStoryByHeroId(idHero);
        }




    }
    // Holder - END
}
