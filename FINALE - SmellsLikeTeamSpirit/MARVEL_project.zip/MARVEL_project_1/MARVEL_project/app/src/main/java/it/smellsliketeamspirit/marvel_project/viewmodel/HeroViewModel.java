package it.smellsliketeamspirit.marvel_project.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import it.smellsliketeamspirit.marvel_project.entities.Hero;


@SuppressWarnings("unused")
public class HeroViewModel extends ViewModel {
    private MutableLiveData<Hero> info;

    public LiveData<Hero> getInfo() {
        if(info == null)
            info = new MutableLiveData<>();
        return info;
    }

    public void loadInfo(Hero hero) {
        if(info == null)
            info = new MutableLiveData<>();
        info.setValue(hero);
    }
}
