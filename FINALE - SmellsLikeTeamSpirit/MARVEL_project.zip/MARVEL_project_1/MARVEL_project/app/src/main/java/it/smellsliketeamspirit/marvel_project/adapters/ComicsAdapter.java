package it.smellsliketeamspirit.marvel_project.adapters;

import android.content.Context;
import android.graphics.Bitmap;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageRequest;

import java.util.List;

import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.entities.Comic;
import it.smellsliketeamspirit.marvel_project.interfaces.SelectMode;

@SuppressWarnings("unused")
public abstract class ComicsAdapter extends RecyclerView.Adapter<ComicsAdapter.Holder>
        implements View.OnClickListener {

    private final List<Comic> comics;
    private RequestQueue queue;

    public abstract void onClickAdapterCallBack(it.smellsliketeamspirit.marvel_project.entities.Comic comics);

    public List<it.smellsliketeamspirit.marvel_project.entities.Comic> getComics() {
        return comics;
    }


    protected ComicsAdapter(Context context, List<it.smellsliketeamspirit.marvel_project.entities.Comic> all, SelectMode listener) {
        comics = all;
// Uso della cache
        Cache cache = new DiskBasedCache(context.getCacheDir(), 16 * 1024 * 1024); // 16MB
        Network network = new BasicNetwork(new HurlStack());
        queue = new RequestQueue(cache, network);
        queue.start();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CardView cl;
        cl = (CardView) LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.row_item, parent, false);
        cl.setOnClickListener(this);
        //cl.setOnLongClickListener(this);
        return new Holder(cl);
    }


    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        Comic comic = comics.get(position);
        holder.tvName.setText(comic.getTitle());

        getImage(position, comic.getMarvelImage().getFullPathMedium(), holder.ivItem);

    }

    private void getImage(int position, String strComicThumb, final ImageView imageView) {
        queue.cancelAll(position);
        ImageRequest imageRequest = new ImageRequest(strComicThumb,
                imageView::setImageBitmap, 0, 0, null, Bitmap.Config.ARGB_8888,
                error -> imageView.setImageResource(R.drawable.ic_launcher_background));
        imageRequest.setTag(position);
        queue.add(imageRequest);
    }


    @Override
    public void onClick(View v) {

        int position = ((RecyclerView) v.getParent()).getChildAdapterPosition(v);
        Comic comic = comics.get(position);
        onClickAdapterCallBack(comic);

    }

    public int getItemCount() {
        return comics.size();
    }

    static class Holder extends RecyclerView.ViewHolder{

        final TextView tvName;
        final ImageView ivFav;
        final ImageView ivItem;
        ConstraintLayout  clContainer;

        Holder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            ivItem = itemView.findViewById(R.id.ivItem);
            ivFav = itemView.findViewById(R.id.ivFav);
            clContainer = itemView.findViewById(R.id.touch_layout);

        }
    }
}
