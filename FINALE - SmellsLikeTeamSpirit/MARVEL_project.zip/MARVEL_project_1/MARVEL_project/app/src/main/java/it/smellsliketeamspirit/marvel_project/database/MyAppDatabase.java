package it.smellsliketeamspirit.marvel_project.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import it.smellsliketeamspirit.marvel_project.entities.FavouriteHero;

@SuppressWarnings("unused")
@Database(entities={FavouriteHero.class}, version = 1)
public abstract class MyAppDatabase extends RoomDatabase {

    private static MyAppDatabase instance;
    public abstract MyDAO myDAO();


    public static synchronized MyAppDatabase getInstance(Context context){
        if(instance == null){
            instance =Room.databaseBuilder(context.getApplicationContext(),
                    MyAppDatabase.class, "marveldb")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
