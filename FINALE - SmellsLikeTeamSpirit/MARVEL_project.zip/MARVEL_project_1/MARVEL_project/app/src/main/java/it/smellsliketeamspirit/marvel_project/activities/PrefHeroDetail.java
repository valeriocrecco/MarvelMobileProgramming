package it.smellsliketeamspirit.marvel_project.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import it.smellsliketeamspirit.marvel_project.MainActivity;
import it.smellsliketeamspirit.marvel_project.entities.FavouriteHeroDetail;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Objects;

import it.smellsliketeamspirit.marvel_project.R;

import org.parceler.Parcels;

public class PrefHeroDetail extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pref_details);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home);

        Parcelable parcelable = getIntent().getParcelableExtra("DATA_KEY");
        FavouriteHeroDetail favouriteHeroDetail = Parcels.unwrap(parcelable);


        assert favouriteHeroDetail != null;
        String heroImage = favouriteHeroDetail.getHeroImg();
        String heroName = favouriteHeroDetail.getHeroName();
        String heroDescription = favouriteHeroDetail.getHeroDescription();
        ImageView ivSeries;
        ImageView ivStories;

        TextView tvName = findViewById(R.id.tvHeroName);
        TextView tvDescription = findViewById(R.id.tvHeroDescription);
        ImageView imgHero = findViewById(R.id.ivHero);
        ivSeries = findViewById(R.id.ibSeries);
        ivStories = findViewById(R.id.ibStories);

        ivSeries.setOnClickListener((v ->{
            String idHero = String.valueOf(favouriteHeroDetail.getHeroId());
            Intent intent = new Intent(PrefHeroDetail.this, SearchHeroSeries.class);
            intent.putExtra("idHERO", idHero);
            intent.putExtra("heroName", heroName);
            startActivity(intent);
        }));


        ivStories.setOnClickListener((v ->{
            String idHero = String.valueOf(favouriteHeroDetail.getHeroId());
            Intent intent = new Intent(PrefHeroDetail.this, SearchStory.class);
            intent.putExtra("idHERO", idHero);
            startActivity(intent);
        }));



        tvName.setText(heroName.toUpperCase());
        if(heroDescription == null || heroDescription.equals("null") || heroDescription.equals("") || heroDescription.equals(" ")){
            tvDescription.setText("Description not available");
        }else{
            tvDescription.setText(heroDescription);
        }


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            URL url = new URL(heroImage);
            imgHero.setImageBitmap(BitmapFactory.decodeStream((InputStream)url.getContent()));
        } catch (IOException ignored) {

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){   //"gonfio" il menu_main
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){  //chiamata per ogni voce menu

        if(item.getItemId()==R.id.mnu_about) {
            Intent infoIntent = new Intent(this, about.class);
            startActivity(infoIntent);
        }

        if(item.getItemId() == android.R.id.home){
            Intent infoIntent1 = new Intent(this, MainActivity.class);
            startActivity(infoIntent1);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);


    }
}
