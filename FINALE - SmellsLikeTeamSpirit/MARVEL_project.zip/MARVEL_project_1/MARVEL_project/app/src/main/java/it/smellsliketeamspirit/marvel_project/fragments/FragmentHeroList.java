package it.smellsliketeamspirit.marvel_project.fragments;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import it.smellsliketeamspirit.marvel_project.R;
import it.smellsliketeamspirit.marvel_project.adapters.HeroAdapter;
import it.smellsliketeamspirit.marvel_project.entities.Hero;
import it.smellsliketeamspirit.marvel_project.interfaces.NextFragment;
import it.smellsliketeamspirit.marvel_project.interfaces.SelectMode;
import it.smellsliketeamspirit.marvel_project.requests.HeroAPI;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroListViewModel;
import it.smellsliketeamspirit.marvel_project.viewmodel.HeroViewModel;

@SuppressWarnings("unused")
public class FragmentHeroList extends Fragment implements SelectMode {

    private HeroAdapter heroAdapter;
    private RecyclerView rv;
    private HeroAPI api;
    private NextFragment nf;
    private HeroListViewModel hlvm;

    private HeroViewModel hvm;

    public FragmentHeroList() {

    }

    public FragmentHeroList(NextFragment nf) {
        this.nf = nf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_hero_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Holder holder = new Holder(view);
        hlvm = new ViewModelProvider(requireActivity()).get(HeroListViewModel.class);
        hlvm.getHeroes().observe(getViewLifecycleOwner(), holder::setList);
    }

    private void onClickAPICallBack(Hero hero) {
        hvm = new ViewModelProvider(requireActivity()).get(HeroViewModel.class);
        hvm.loadInfo(hero);

        if (nf != null) {
            nf.nextFragment();
        }
    }

    @Override
    public void onStop() {
        if(heroAdapter != null)
            hlvm.setHeroes(heroAdapter.getHeroes());
        super.onStop();
    }

    @Override
    public void onSelect(int size) {

    }



    class Holder implements View.OnClickListener, TextView.OnEditorActionListener {

        EditText etSearch;
        Button btnSearch;
        RadioGroup radioGroupSearch;


        Holder(View fl) {
            etSearch = fl.findViewById(R.id.etSearch);
            btnSearch = fl.findViewById(R.id.btnSearch);
            radioGroupSearch = fl.findViewById(R.id.rd_choice);

            etSearch.setOnEditorActionListener(this);
            btnSearch.setOnClickListener(this);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
            rv = fl.findViewById(R.id.rvHeroList);
            rv.setLayoutManager(layoutManager);
            if(getActivity() != null) {
                api = new HeroAPI(getActivity()) {
                    public void fillLayout(List<Hero> heroes) {
                        heroAdapter = new HeroAdapter(getActivity(), heroes, FragmentHeroList.this) {
                            @Override
                            public void onClickAdapterCallBack(Hero hero) {
                                onClickAPICallBack(hero);
                            }
                        };
                        rv.setAdapter(heroAdapter);
                        hlvm.setHeroes(heroAdapter.getHeroes());
                    }
                };
            }
            if(getContext() != null) {
                Drawable drw = ContextCompat.getDrawable(getContext(), R.drawable.my_divider);
                if (drw != null) {
                    DividerItemDecoration itemDecorator = new DividerItemDecoration(getContext(),
                            DividerItemDecoration.VERTICAL);
                    itemDecorator.setDrawable(drw);
                    rv.addItemDecoration(itemDecorator);
                }
            }
        }

        private void searchByCompleteName() {
            api.searchHeroesByName(etSearch.getText().toString());
        }

        private void searchByInitialName() {
            api.searchHeroesByNameStartsWith(etSearch.getText().toString());
        }

        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                int checkedId = radioGroupSearch.getCheckedRadioButtonId();
                if(checkedId == -1){
                    //no radio button are
                }else{
                    findRadioButton(checkedId);
                }
                return false;
            }
            return false;
        }

        private void findRadioButton(int checkedId){
            switch(checkedId){
                case R.id.rb_radio_name_init:
                    searchByInitialName();
                    break;

                case R.id.rb_radio_name_complete:
                    searchByCompleteName();
                    break;
            }
        }

        @Override
        public void onClick(View v) {

            int checkedId = radioGroupSearch.getCheckedRadioButtonId();
            if(checkedId == -1){
                //no radio button are
            }else{
                findRadioButton(checkedId);
            }

        }



        void setList(List<Hero> heroes) {
            if (heroes == null)
                return;
            if(getActivity() != null) {
                heroAdapter = new HeroAdapter(getActivity(), heroes, FragmentHeroList.this) {
                    @Override
                    public void onClickAdapterCallBack(Hero hero) {
                        onClickAPICallBack(hero);
                    }
                };
                rv.setAdapter(heroAdapter);
            }
        }
    }

}
