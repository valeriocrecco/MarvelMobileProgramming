package it.smellsliketeamspirit.marvel_project.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


import java.util.List;
@SuppressWarnings("unused")
public class ComicsViewModel extends ViewModel {
    private MutableLiveData<List<it.smellsliketeamspirit.marvel_project.entities.Comic>> comics;
    public LiveData<List<it.smellsliketeamspirit.marvel_project.entities.Comic>> getComics() {
        if(comics == null)
            comics = new MutableLiveData<>();
        return comics;
    }

    public void setComics(List<it.smellsliketeamspirit.marvel_project.entities.Comic> cocktails) {
        this.comics.setValue(cocktails);
    }

}
