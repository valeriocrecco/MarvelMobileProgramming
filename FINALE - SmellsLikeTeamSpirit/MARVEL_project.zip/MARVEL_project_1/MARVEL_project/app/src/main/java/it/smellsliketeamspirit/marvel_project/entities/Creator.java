package it.smellsliketeamspirit.marvel_project.entities;

import android.os.Parcel;
import android.os.Parcelable;
@SuppressWarnings("unused")
public class Creator implements Parcelable {

    private String resURI;
    private String name;
    private String role;

    public Creator(String resURI, String name, String role) {
        this.resURI = resURI;
        this.name = name;
        this.role = role;
    }
    public Creator(String resURI, String name) {
        this.resURI = resURI;
        this.name = name;
    }

    public String getResURI() {
        return resURI;
    }

    public void setResURI(String resURI) {
        this.resURI = resURI;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public static final Creator<it.smellsliketeamspirit.marvel_project.entities.Creator> CREATOR = new Creator<it.smellsliketeamspirit.marvel_project.entities.Creator>() {
        @Override
        public it.smellsliketeamspirit.marvel_project.entities.Creator createFromParcel(Parcel in) {
            return new it.smellsliketeamspirit.marvel_project.entities.Creator(in);
        }

        @Override
        public it.smellsliketeamspirit.marvel_project.entities.Creator[] newArray(int size) {
            return new it.smellsliketeamspirit.marvel_project.entities.Creator[size];
        }
    };

    private Creator(Parcel in) {
        name = in.readString();
        resURI = in.readString();
        role = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(resURI);
        dest.writeString(name);
        dest.writeString(role);
    }
}
